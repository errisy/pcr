//to be include for database access
var data;
(function (data) {
    var port = (function () {
        /**
         * create the MySQLi connection with the server name, username, password and database;
         */
        function port(server, username, password, database) {
            this.mySQLi = mysqli_connect(server, username, password, database);
        }
        /**
         * this initialize a MySQL statement query; you have to bind parameters with the 'bind_param' method of the statement;
         * @param sql
         */
        port.prototype.createStatement = function (sql) {
            var stmt = this.mySQLi.stmt_init();
            stmt.prepare(sql);
            return stmt;
        };
        /**
         * this method will execute the mysql statement and reteurn the array of data objects, they are ready for json encoding;
         * @param stmt
         */
        port.prototype.getDataObjects = function (stmt) {
            stmt.execute();
            var list = array();
            var resultMetadata = stmt.result_metadata();
            if (resultMetadata) {
                var fields = array();
                var fieldmeta;
                while (fieldmeta = mysqli_fetch_field(resultMetadata)) {
                    array_push(fields, fieldmeta.name);
                }
                mysqli_free_result(resultMetadata);
                var result = stmt.get_result();
                var row;
                while (row = mysqli_fetch_array(result)) {
                    var obj = array();
                    for (var i = 0; i < sizeof(fields); i++) {
                        obj[fields[i]] = row[i];
                    }
                    array_push(list, obj);
                }
                mysqli_free_result(result);
            }
            return list;
        };
        /**
         * This method fetch the value from the key-value array object; it is very useful for the 'Count' query;
         * @param arr
         */
        port.prototype.fetchFirstValue = function (arr) {
            for (var key in arr) {
                return arr[key];
            }
        };
        /**
         * This method fetch the key and value from the key-value array object; it is useful for specific type of queries;
         * @param arr
         */
        port.prototype.fetchFirstKeyValuePair = function (arr) {
            for (var key in arr) {
                var kvp = new KeyValuePair();
                kvp.key = key;
                kvp.value = arr[key];
                return kvp;
            }
        };
        /**
         * Close the MySQLi connection at the end of the query;
         */
        port.prototype.__destruct = function () {
            this.mySQLi.close();
        };
        return port;
    }());
    data.port = port;
    var KeyValuePair = (function () {
        function KeyValuePair() {
        }
        return KeyValuePair;
    }());
})(data || (data = {}));
//# sourceMappingURL=mysqli.js.map