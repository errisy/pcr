﻿//cf
module MarketSpecial {
    export class Company{
        public id: number = cf.PrimaryKey().AutoIncrement().Int();
        public name: string = cf.VarChar(80);
        public address: string = cf.VarChar(255);
        public creation: Date = cf.Date();
    }
}