<?php
namespace MarketSpecial{
	class Company{
		public $id;
		public $name;
		public $address;
	}
	$MarketSpecial_Company = "Create Table 'MarketSpecial'.'Company'('id' Int  Not Null AUTO_INCREMENT , 'name' VARCHAR(80)', 'address' VARCHAR(255)', Primary Key ('id'));";
}
?>