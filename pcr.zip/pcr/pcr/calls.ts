﻿//rpc include 'dataData' 'mysqli'

module login {
    export interface login {
        login(method: string): boolean;
    }
}