﻿/**
 * This class is for the definition of MySQL database from Typescript;
 * Basically, it will generate queries for accessing proper type of database;
 * Each access must be verified by username and password check.
 */
class cf {
    /**
     * Define a variable char with speicific length;
     * @param length
     */
    static VarChar(length: number): string {
        return '';
    };
    /**
     * Define a text field in MySQL
     */
    static Text(): string {
        return '';
    }
    /**
     * Define a decimal number with specific length and scale;
     * @param length
     * @param scale
     */
    static Decimal(length: number, scale: number): number {
        return 0;
    };
    /**
     * Define an int number;
     */
    static Int(): number {
        return 0;
    }
    static Bool(): boolean {
        return false;
    }
    /**
     * Define a small int;
     */
    static SmallInt(): number {
        return 0;
    }
    static TinyInt(): number {
        return 0;
    }
    static BigInt(): number {
        return 0;
    }
    static Date(): Date {
        return new Date();
    }
    static Time(): Date {
        return new Date();
    }
    static DateTime(): Date {
        return new Date();
    }
    static TimeStamp(): Date {
        return new Date();
    }

    /**
     * Define how a field is linked to other classes;
     * @param keyField You must use '(new Classname).property' expression to assign this;
     */
    static ArrayOf<T>(keyField: string) {
        return null;
    }
    static ReferenceOf<T>(keyField: string) {
        return null;
    }
    static MD5Password() {
        return cf;
    }
    /**
     * By speicify the login method, the php side will create a login method for you to call;
     * However, in order to simplify server logic, we will not create a very complex php query script with built-in login verification.
     * @param info
     */
    static Username() {
        return cf;
    }
    static Password() {
        return cf;
    }
    /**
     * It allows the creation of a new kind of table by the name of that system.
     * @param name
     */
    static SubTable(name: string): string {
        return '';
    }
    static PrimaryKey() {
        return cf;
    }
    static Unique() {
        return cf;
    }
    static ZeroFill() {
        return cf;
    }
    static AutoIncrement() {
        return cf;
    }
    static NotNull() {
        return cf;
    }
    static DefaultString(value: string) {
        return cf;
    }
    static DefaultNumber(value: number) {
        return cf;
    }
    static Verify(entity: Function) {
        return cf;
    }
    static Login<T>(): (http: ng.IHttpService, entity: T) => boolean {
        return (http: ng.IHttpService, entity: T) => { return true };
    }
    static Update<T>(): (http: ng.IHttpService, entity: T) => boolean {
        return (http: ng.IHttpService, entity: T) => { return true };
    }
    static UpdateArray<T>(): (http: ng.IHttpService, entity: T[]) => boolean {
        return (http: ng.IHttpService, entity: T[]) => { return true };
    }
}

interface IQuery {
    query();
}

class CFCompiler {
    public code: string;
    public databases: CFDatabase[] = [];
    constructor(code: string) {
        var arr: CFDatabase[] = [];
        var codeSections = SectionDivider.Divide(code, CFDatabase.ptnModule);
        for (var i: number = 0; i < codeSections.length; i++) {
            var mt = CFDatabase.ptnModule.Match(codeSections[i]);
            var mDatabase = new CFDatabase(codeSections[i]);
            arr.push(mDatabase);
        }
        this.code = code;
        var mc = StdPatterns.ptnModule.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end: number;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _database = new CFDatabase(this.code.substring(begin, end));
            _database.name = mt.groups[2];
            _database.begin = begin;
            _database.parent = this;
            this.databases.push(_database);
        }
    }
}
class CFDatabase {
    static ptnModule = /^\s*module\s+(\w+)\s*\{/g;
    constructor(value: string) {
        //analyze value to obtain the name of table;
        this.code = value;
        var mc = CompilerPattern.ptnService.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end: number;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _table = new CFTable(this.code.substring(begin, end));
            _table.parent = this;
            _table.name = mt.groups[4];
            _table.begin = begin;
            this.tables.push(_table);
        }

    }
    public name: string;
    public begin: number;
    public parent: CFCompiler;
    public code: string;
    public tables: CFTable[] = [];
    public getDatabaseCreateQuery(): string {
        var CreateQueries: string[] = [];
        for (var i: number = 0; i < this.tables.length; i++) {
            CreateQueries.push(this.tables[i].create);
        }
        return CreateQueries.join(';');
    }
    get ts(): string {
        var builder: string[] = [];
        builder.push('module ' + this.name + 'Data {\n');
        for (var i: number = 0; i < this.tables.length; i++) {
            builder.push(this.tables[i].ts);
        }
        //codes for create and drop tables;
        builder.push('\texport class TableCreation {\n');
        for (var i: number = 0; i < this.tables.length; i++) {
            builder.push('\t\tpublic ', this.name, '_', this.tables[i].name, ':string = "', this.tables[i].create, '";\n');
        }
        builder.push('\t}\n');
        builder.push('}\n');
        return builder.join('');
    }
}
class CFTable {
    static ptnTable = /(^|\n)\s*(export\s+|)class\s+(\w+)\s*\{/g;
    constructor(value: string) {
        //analyze value to obtain the name of table;
        this.code = value;
        var fieldSections = SectionDivider.DivideWith(this.code, /(^\s*|(;)[\s^\n]*\n[\s^\n]*)/g, 2);

        //console.log(fieldSections);
        for (var j: number = 0; j < fieldSections.length; j++) {
            //var mt = CFDatabase.ptnModule.Match(fieldSections[i]);

            var mt: RegularExpressionMatch;
            var fieldcode = fieldSections[j];
            console.log(fieldcode);

            for (var i: number = 0; i < FieldModels.length; i++) {
                var fm = FieldModels[i];
                if (fm.pattern.IsMatch(fieldcode)) {
                    //console.log(fieldcode);
                    var field = new CFField(fieldcode);
                    var mt = fm.pattern.Match(fieldcode);
                    fm.setFeild(mt, field);
                    //this.Name = mt.groups[3];
                    //this.Model = fm;
                    //this.Attributes = mt.groups[4];
                    //this.FieldType = mt.groups[6];
                    //if (mt.groups[7]) this.Length = Number(mt.groups[7]);
                    //if (mt.groups[8]) this.Scale = Number(mt.groups[8]);
                    if (CFField.ptnPrimaryKey.IsMatch(field.attributes)) {
                        console.log('PrimaryKey ' + field.name);
                        field.isPrimaryKey = true;
                        field.isNotNull = true;
                    }
                    if (CFField.ptnNotNull.IsMatch(field.attributes)) {
                        field.isNotNull = true;
                    }
                    if (CFField.ptnAutoIncrement.IsMatch(field.attributes) && fm.canAutoIncrement) {
                        field.isAutoIncrement = true;
                    }
                    if (fm.canDefaultString) if (CFField.ptnDefaultString.IsMatch(field.attributes)) {

                        var md = CFField.ptnDefaultString.Match(field.attributes);
                        field.hasDefaultValue = true;
                        field.defaultValue = md.groups[1];
                        console.log('default string: ' + field.defaultValue);
                    }
                    if (fm.canDefaultNumber) if (CFField.ptnDefaultNumber.IsMatch(field.attributes)) {
                        var md = CFField.ptnDefaultNumber.Match(field.attributes);
                        field.hasDefaultValue = true;
                        field.defaultValue = md.groups[1];
                        console.log('default number: ' + field.defaultValue);
                    }
                    console.log(field);
                    this.fields.push(field);
                }
            }
        }
    }
    public name: string;
    public code: string;
    public begin: number;
    public parent: CFDatabase;
    public fields: CFField[] = [];
    get create(): string {
        var builder: Array<string> = [];
        builder.push('Create Table ',  this.parent.name , '.' , this.name , '(');
        var primaryKeyField: CFField;

        var defs: Array<string> = [];

        for (var i: number = 0; i < this.fields.length; i++) {
            //the first primary key field is valid.
            if (!primaryKeyField && this.fields[i].isPrimaryKey) primaryKeyField = this.fields[i];
            defs.push(this.fields[i].definition);
            //console.log('def: ' + this.Fields[i].getFieldDefinition());
        }

        if (primaryKeyField) {
            defs.push("Primary Key (" + primaryKeyField.name + ')')
        }

        builder.push(defs.join(', '));
        builder.push(');');
        return builder.join('');
    }
    get ts(): string {
        var builder: string[] = [];
        builder.push('\texport class ' + this.name + '{\n');
        for (var i: number = 0; i < this.fields.length; i++) {
            builder.push(this.fields[i].ts);
        }
        builder.push('\t}\n');
        return builder.join('');
    }
    get dts(): string {
        return '';
    }
}

class FieldModel {
    public name: string;
    public pattern: RegExp;
    public canAutoIncrement: boolean;
    public canDefaultString: boolean;
    public canDefaultNumber: boolean;
    public setFeild: (match: RegularExpressionMatch, field: CFField) => void;
}

var FieldModels: FieldModel[] = [
    {
        name: 'VarChar',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'string'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*string\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(VarChar)\s*\(\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Decimal',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); f.scale = Number(m.groups[8]); },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Decimal)\s*\(\s*(\d+)\s*\,\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Int',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Int)\s*\(\s*\)\s*;/g
    },
    {
        name: 'BigInt',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(BigInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'TinyInt',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(TinyInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Bool',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Bool)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Text',
        setFeild: (m: RegularExpressionMatch, f: CFField) => { f.model = f.model; f.tsType = 'string'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*string\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Text)\s*\(\s*\)\s*;/g
    }
];

class CFField {
    static ptnPrimaryKey = /PrimaryKey\s*\(\s*\)/g;
    static ptnNotNull = /NotNull\s*\(\s*\)/g;
    static ptnAutoIncrement = /AutoIncrement\s*\(\s*\)/g;
    static ptnDefaultString = /DefaultString\s*\(\s*(('|")[^']+('|"))\s*\)/g;
    static ptnDefaultNumber = /DefaultNumber\s*\(\s*((\-|)[\d\.]+)\s*\)/g;
    constructor(value: string) {
        this.code = value;
    }
    public name: string;
    public attributes: string;
    public parent: CFTable;
    public code: string;
    public model: FieldModel;
    public defaultValue: string;
    public fieldType: string;
    public tsType: string;
    public length: number;
    public scale: number;
    public isPrimaryKey: boolean;
    public isNotNull: boolean;
    public isUnique: boolean;
    public isZeroFill: boolean;
    public isAutoIncrement: boolean;
    public hasDefaultValue: boolean;
    get definition(): string {
        //console.log('Name: ' + this.Name);
        //console.log(this.FieldType);
        switch (this.fieldType) {
            case 'VarChar':
                //console.log('case: VarChar');
                return  this.name 
                    + ' VARCHAR(' + this.length + ')'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue + '\'': '');
            case 'Int':
                return  this.name 
                    + ' Int '
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.isAutoIncrement) ? ' AUTO_INCREMENT ' : '')
                    + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
            case 'Decimal':
                return  this.name 
                    + ' Deciaml(' + this.length + ',' + this.scale + ')'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
            case 'TinyInt':
                return  this.name 
                    + ' TinyInt'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
            case 'BigInt':
                return this.name 
                    + ' BigInt'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
            case 'Bool':
                return this.name
                    + ' TinyInt(1)'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
            case 'Text':
                return this.name
                    + ' Text'
                    + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                    + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue + '\'' : '\'');
        }
    }

    get ts(): string {
        return '\t\tpublic ' + this.name + ':' + this.tsType + ';\n';
    }
}

//rpc
//this file defines classes that can convert interfaces to PHP based remote procedure calls;

class RPCCompiler {
    public code: string;
    public modules: RPCModule[] = [];

    public references: string[] = [];
    constructor(value: string) {
        console.log(value);
        this.code = value;
        var mi = CompilerPattern.ptnRPCInclude.Match(value);
        var includevalues = mi.groups[2];
        console.log('rpc includes:' + value); 
        if (includevalues) if (includevalues.length > 0) {
            var includes = CompilerPattern.ptnIncludeFile.Matches(includevalues);
            for (var i: number = 0; i < includes.length; i++) {
                var inc = includes[i];
                this.references.push(inc.groups[1]);
            }
        }
        var mc = StdPatterns.ptnModule.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end: number;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _module = new RPCModule(this.code.substring(begin, end));
            _module.name = mt.groups[2];
            _module.begin = begin;
            _module.parent = this;
            this.modules.push(_module);
        }
        console.log(this.modules);
    }
    get client(): string {
        var builder: string[] = [];
        for (var i: number = 0; i < this.modules.length; i++) {
            builder.push(this.modules[i].client);
        }
        return builder.join('');
    }
    get service(): string {
        var builder: string[] = [];
        for (var i: number = 0; i < this.modules.length; i++) {
            builder.push(this.modules[i].service);
        }
        return builder.join('\n');
    }
}
class RPCModule {
    public name: string;
    public services: RPCService[] = [];
    public code: string;
    public begin: number;
    public parent: RPCCompiler;

    constructor(value: string) {
        this.code = value;
        var mc = CompilerPattern.ptnService.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end: number;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _service = new RPCService(this.code.substring(begin, end));
            _service.parent = this;
            _service.name = mt.groups[4];
            _service.begin = begin;
            this.services.push(_service);
        }
    }
    get client(): string {
        var builder: string[] = [];
        builder.push('module ', this.name, 'Client', ' {\n');
        for (var i: number = 0; i < this.services.length; i++) {
            builder.push(this.services[i].client);
        }
        builder.push('\n}\n');
        return builder.join('');
    }
    public implant = (old: string, name: string): string => {
        name = name + 'Service';
        if (!old) return this.service;

        var ptnAUTO = /\/\/\-\-\-AUTOGENERATED\sCODE\sBELOW/g;
        var mtAUTO = ptnAUTO.Match(old);
        var end: number;
        if (mtAUTO) {
            end = mtAUTO.index;
        }
        else {
            end = old.length;
        }
        var start: number;
        var mtPHP = CompilerPattern.ptnPHPInclude.Match(old);
        if (mtPHP) {
            start = mtPHP.length;
        }
        else {
            start = 0;
        }
        var mod: string = old.substring(start, end);

        var _oldModule: RPCModule;
        //the following codes will find out the module matching this name;
        console.log('mod code:');
        console.log(mod);
        var mc = StdPatterns.ptnModule.Matches(mod);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = mod.indexOf('{', mt.index) + 1;
            var end: number;
            if (mc[i + 1]) {
                end = mod.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = mod.lastIndexOf('}', mod.length);
            }
            if (mt.groups[2] == name) {
                _oldModule = new RPCModule(mod.substring(begin, end));
                _oldModule.begin = begin;
                _oldModule.name = name;
            }
        }

        if (_oldModule) {
            console.log('module found');
            var _insertions = _oldModule.update(this);
            console.log(_insertions);
            _insertions.sort(Insertion.Compare);
            var index = 0;
            var builder: string[] = [];
            builder.push(this.reference);
            for (var i: number = 0; i < _insertions.length; i++) {
                console.log('Section ' + i.toString() + ' at ' + _insertions[i].index.toString() + ': ' + mod.substring(0, _insertions[i].index));
                builder.push(mod.substring(index, _insertions[i].index));
                console.log('Insertion ' + i.toString() + ': ' + _insertions[i].value);
                builder.push(_insertions[i].value);
                index = _insertions[i].index;
            }
            if (_insertions.length > 0) {
                console.log('final: ' + mod.substring(_insertions[_insertions.length - 1].index, mod.length));
                builder.push(mod.substring(index, mod.length));
            }
            else {
                builder.push(mod);
            }
            builder.push(this.dispatcher);
            return builder.join('');
        }
        else {
            console.log('module not found');
            return this.service;
        }
    }
    public update = (updated: RPCModule): Insertion[] => {
        console.log(this);
        console.log(updated);
        var _insertions: Insertion[] = [];
        var newServices: RPCService[] = [];
        for (var i: number = 0; i < updated.services.length; i++) {
            if (this.hasService(updated.services[i])) {
                console.log('has Service: ' + updated.services[i].name);
                var _service = this.getService(updated.services[i].name);
                _insertions.push(_service.update(updated.services[i]));
            }
            else {
                //put the new services in the array, they will be added at the end of the update;
                console.log('not has Service: ' + updated.services[i].name);
                newServices.push(updated.services[i]);
            }
        }
        var builder: string[] = [];
        for (var i: number = 0; i < newServices.length; i++) {
            builder.push('\n', newServices[i].service);
        }
        if (newServices.length > 0) {
            //builder.push('\n');
        }
        var _insertion = new Insertion();
        _insertion.index = this.begin;
        _insertion.value = builder.join('');
        _insertions.push(_insertion);
        return _insertions;
    }
    public hasService = (service: RPCService): boolean => {
        for (var i: number = 0; i < this.services.length; i++) {
            if (this.services[i].name == service.name) return true;
        }
        return false;
    }
    public getService = (name: string): RPCService => {
        for (var i: number = 0; i < this.services.length; i++) {
            if (this.services[i].name == name) return this.services[i];
        }
        return null;
    }
    get reference(): string {

        var refbuilder: string[] = [];
        refbuilder.push('\'rpcdef\'');
        console.log('references: ');
        console.log(this.parent.references);
        for (var i: number = 0; i < this.parent.references.length; i++) {
            refbuilder.push('\'' + this.parent.references[i] + '\'');
        }
        return '//php include ' + refbuilder.join(' ') + ' \n';
    }
    get service(): string {
        var builder: string[] = [];
        /*
var postInput = file_get_contents("php://input");
var jsonObject: rpc = json_decode(postInput);
//call dispatcher;
switch (jsonObject.service) {

}
        */
        builder.push(this.reference);

        builder.push('module ', this.name, 'Service', ' {\n');
        for (var i: number = 0; i < this.services.length; i++) {
            builder.push(this.services[i].service);
        }
        builder.push('\n}\n');


        builder.push(this.dispatcher);
        return builder.join('');
    }
    get dispatcher(): string {
        var builder: string[] = [];
        builder.push('//---AUTOGENERATED CODE BELOW: typescript dispatcher for php, please do not modify any code blow \n');

        builder.push('var postInput = file_get_contents("php://input");\n');
        builder.push('var jsonObject: rpc = json_decode(postInput);\n');
        //builder.push('//Dispatch serices and calls to object;\n');
        builder.push('switch (jsonObject.service) {\n');

        for (var i: number = 0; i < this.services.length; i++) {
            builder.push(this.services[i].dispatcher);
        }
        builder.push('}\n');
        return builder.join('');
    }

}
class RPCService {
    public name: string;
    public methods: RPCMethod[] = [];
    public code: string;
    public begin: number;
    public parent: RPCModule;
    constructor(value: string) {
        this.code = value;
        var mc = StdPatterns.ptnInterfaceMethod.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var _method = new RPCMethod(mt.groups[2]);
            _method.name = mt.groups[1];
            _method.returnType = mt.groups[8].split(' ').join('');
            _method.parent = this;
            this.methods.push(_method);
        }
    }
    public update = (updated: RPCService): Insertion => {
        var newMethods: RPCMethod[] = [];
        for (var i: number = 0; i < updated.methods.length; i++) {
            if (this.hasMethod(updated.methods[i])) {
                var _method = this.getMethod(updated.methods[i].name);
                if (!_method.isIndentical(updated.methods[i])) {
                    //if the new method is different from the old one, we still need to insert the new methods;
                    newMethods.push(updated.methods[i]);
                }
            }
            else {
                //put the new methods in the array, they will be added at the end of the update;
                newMethods.push(updated.methods[i]);
            }
        }
        var builder: string[] = [];
        for (var i: number = 0; i < newMethods.length; i++) {
            builder.push('\n', newMethods[i].service);
        }
        //if (newMethods.length > 0) builder.push('\n');
        var _insertion = new Insertion();
        _insertion.index = this.parent.begin + this.begin;
        _insertion.value = builder.join('');
        return _insertion;
    }
    public hasMethod = (method: RPCMethod): boolean => {
        for (var i: number = 0; i < this.methods.length; i++) {
            if (this.methods[i].name == method.name) return true;
        }
        return false;
    }
    public getMethod = (name: string): RPCMethod => {
        for (var i: number = 0; i < this.methods.length; i++) {
            if (this.methods[i].name == name) return this.methods[i];
        }
        return null;
    }
    get client(): string {
        var builder: string[] = [];
        builder.push('  export class ', this.name, ' {\n');
        for (var i: number = 0; i < this.methods.length; i++) {
            builder.push(this.methods[i].client);
        }
        builder.push('  }\n');
        return builder.join('');
    }
    get dispatcher(): string {
        var builder: string[] = [];
        /*
    case 'newcall':
        var serviceObject = new newcallService();
        switch (jsonObject.method) {

        }
        break;
        */
        builder.push('    case \'', this.name, '\':\n');
        builder.push('        var ', this.parent.name, '_', this.name, ' = new ', this.parent.name, 'Service.', this.name, '();\n');
        builder.push('        switch (jsonObject.method) {\n');
        for (var i: number = 0; i < this.methods.length; i++) {
            builder.push(this.methods[i].dispatcher);
        }
        builder.push('        }\n');
        builder.push('        break;\n');
        return builder.join('');
    }
    get service(): string {
        var builder: string[] = [];
        builder.push('  export class ', this.name, ' {\n');
        for (var i: number = 0; i < this.methods.length; i++) {
            builder.push(this.methods[i].service);
        }
        builder.push('  }\n');
        return builder.join('');
    }
}
class RPCMethod {
    public name: string;
    public parameters: RPCParameter[] = [];
    public returnType: string;
    public parent: RPCService;
    public code: string;
    constructor(value: string) {
        this.code = value;
        var mc = StdPatterns.ptnParameter.Matches(this.code);
        for (var i: number = 0; i < mc.length; i++) {
            var mt = mc[i];
            var _parameter = new RPCParameter();
            _parameter.name = mt.groups[1];
            _parameter.type = mt.groups[2].split(' ').join('');
            this.parameters.push(_parameter);
        }
    }
    public isIndentical = (updated: RPCMethod): boolean => {
        //Check if the method is the same one;
        if (this.name != updated.name) return false;
        if (this.returnType != updated.returnType) return false;
        if (this.parameters.length != updated.parameters.length) return false;
        for (var i: number = 0; i < this.parameters.length; i++) {
            if (this.parameters[i].service != updated.parameters[i].service) return false;
        }
        return true;
    }
    get client(): string {
        var builder: string[] = [];
        var pmNames: string[] = [];
        builder.push('      public static ', this.name, ' (');
        for (var i: number = 0; i < this.parameters.length; i++) {
            builder.push(this.parameters[i].client);
            builder.push(', ');
            pmNames.push(this.parameters[i].name);
        }
        builder.push('\n');
        builder.push('          _SuccessCallback: ng.IHttpPromiseCallback<', this.returnType, '>');
        builder.push(', \n');
        builder.push('          _ErrorCallback?: ng.IHttpPromiseCallback<', this.returnType, '>');
        builder.push(') {\n');
        builder.push('          var _RemoteProcedureCallObject: rpc = {\n');
        builder.push('                  service: \'', this.parent.name, '\', method: \'', this.name, '\', parameters: [', pmNames.join(', '), ']\n');
        builder.push('              }\n');
        builder.push('          RPC.http.post(\'', this.parent.parent.name, '.php\', _RemoteProcedureCallObject)\n');
        builder.push('              .success(_SuccessCallback)\n');
        builder.push('              .error(_ErrorCallback);\n');
        builder.push('      }\n');
        return builder.join('');
    }
    get dispatcher(): string {
        var builder: string[] = [];
        /*
            case 'query':
                var remoteCallResult = serviceObject.query(jsonObject.parameters[0]);
                echo(json_encode(remoteCallResult));
        */
        builder.push('          case \'', this.name, '\':\n');

        builder.push('              var ', this.parent.parent.name, '_', this.parent.name, '_', this.name, 'Result = ', this.parent.parent.name, '_', this.parent.name, '.', this.name, '(');
        var pmValues: string[] = [];
        for (var i: number = 0; i < this.parameters.length; i++) {
            pmValues.push('<' + this.parameters[i].type + '>(jsonObject.parameters[' + i.toString() + '])');
        }
        builder.push(pmValues.join(', '));
        builder.push(');\n');
        builder.push('              echo(json_encode(', this.parent.parent.name, '_', this.parent.name, '_', this.name, 'Result));\n');
        builder.push('              break;\n');
        return builder.join('');
    }
    get service(): string {
        var builder: string[] = [];
        var pmNames: string[] = [];
        builder.push('      public ', this.name, ' (');
        for (var i: number = 0; i < this.parameters.length; i++) {
            pmNames.push(this.parameters[i].client);
        }
        builder.push(pmNames.join(', '));
        builder.push('):', this.returnType, '{\n');
        builder.push('          return null;\n');
        builder.push('      }\n');
        return builder.join('');
    }
}
class RPCParameter {
    public name: string;
    public type: string;
    get client(): string {
        return [this.name, ':', this.type].join('');
    }
    get service(): string {
        return [this.name, ':', this.type].join('');
    }
}


var app = new ngstd.AngularModule('pcr', []);

//this file defines the UI for php.html.
class CFCompileTask {
    public name: string;
    public compiled: boolean;
    public include: string;
    public status: string;
    public output: string[];
}
class CFController {
    static $inject = ['$http', '$scope'];

    public test: string;
    public http: ng.IHttpService;
    public scope: ng.IScope;
    public root: Root;
    constructor(public $http: ng.IHttpService, public $scope: ng.IScope) {
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    public files: CFCompileTask[];
    public scan = () => {
        var po = new PHPPostObj();
        po.method = 'ScanCF';
        this.http.post('pcr.php', po)
            .success(this.onReceiveFiles);
    }
    public onReceiveFiles = (data: string[]) => {
        console.log(data);
        this.files = [];
        for (var i: number = 0; i < data.length; i++) {
            this.files.push({
                name: data[i], compiled: false, include: '',status:'detected', output: []
            });
        }
    }
    public compilerIndex: number = -1;
    public compile = () => {
        for (var i: number = 0; i < this.files.length; i++) {
            this.files[i].output = [];
        }
        //needs to get file from the server and compile them;
        if (this.compilerIndex < 0) {
            this.compilerIndex = 0;
            this.compileNext();
        }
    }
    public compileNext = () => {
        if (this.files[this.compilerIndex]) {
            var file = this.files[this.compilerIndex];
            this.http.get(file.name)
                .success(this.onReceiveCode);
        } else {
            //end of compiling
            this.compilerIndex = -1;
        }
    }
    public onError = (data: any, status: number, headers: ng.IHttpHeadersGetter, config: ng.IRequestConfig): void => {
        console.log(headers);
        console.log('status: ' + status.toString());
    }

    public onReceiveCode = (code: string) => {


        var compiler = new CFCompiler(code);
        var file = this.files[this.compilerIndex];
        var po = new PHPPostObj()
        po.method = 'Write';

        //work out the //php and include
        var builder: string[] = [];
        //builder.push('<?php\n');
        //var phpincludes: string[] = [];

        for (var i: number = 0; i < compiler.databases.length; i++) {
            builder.push(compiler.databases[i].ts);
        }

        //builder.push('?>');

        var phpfile = new FileBuiler()
        phpfile.filename = file.name.replace('.ts', 'Data.ts');
        phpfile.content = builder.join('');

        file.status = 'compiled';
        file.output.push(phpfile.filename);

        po.value.push(phpfile);
        console.log(po);
        this.http.post('pcr.php', po)
            .success(this.onWritten)
            .error(this.onError);


    }
    public onWritten = (value: string) => {
        console.log(value);
        this.files[this.compilerIndex].compiled = true;
        //this.scope.$apply();
        this.compilerIndex += 1;
        this.compileNext();
    }
}

//app.addController('cf', CFController);

class RPCCompileTask {
    public name: string;
    public compiled: boolean;
    public compiler: RPCCompiler;
    public status: string;
    public output: string[];
}
class RPCController {
    static $inject = ['$http', '$scope'];

    public test: string;
    public http: ng.IHttpService;
    public scope: ng.IScope;
    public root: Root;
    constructor(public $http: ng.IHttpService, public $scope: ng.IScope) {
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    public files: RPCCompileTask[];
    public scan = () => {
        var po = new PHPPostObj();
        po.method = 'ScanRPC';
        this.http.post('pcr.php', po)
            .success(this.onReceiveFiles);
    }
    public onReceiveFiles = (data: string[]) => {
        console.log(data);
        this.files = [];
        for (var i: number = 0; i < data.length; i++) {
            this.files.push({
                name: data[i], compiled: false, compiler: null, status: 'detected', output: []
            });
        }
    }
    public compilerIndex: number = -1;
    public compile = () => {
        //clear all the existing file outputs
        for (var i: number = 0; i < this.files.length; i++) {
            this.files[i].output = [];
        }
        //needs to get file from the server and compile them;
        if (this.compilerIndex < 0) {
            this.compilerIndex = 0;
            this.compileNext();
        }
    }
    public compileNext = () => {
        if (this.files[this.compilerIndex]) {
            var file = this.files[this.compilerIndex];
            this.http.get(file.name)
                .success(this.onReceiveCode);
        } else {
            //end of compiling
            this.compilerIndex = -1;
            this.root.php.scan();
        }
    }
    public onError = (data: any, status: number, headers: ng.IHttpHeadersGetter, config: ng.IRequestConfig): void => {
        console.log(headers);
        console.log('status: ' + status.toString());
    }
    public onReceiveCode = (code: string) => {
        var compiler = new RPCCompiler(code);
        this.files[this.compilerIndex].compiler = compiler;
        var po = new PHPPostObj()
        po.method = 'Get';
        var filename = this.files[this.compilerIndex].name;
        //var fClient = new FileBuiler();
        //fClient.filename = filename.substr(0,filename.length-3) + 'Client.ts';
        //fClient.content = compiler.client;
        //po.value.push(fClient);
        for (var i: number = 0; i < compiler.modules.length; i++) {
            var fServer = new FileBuiler();
            fServer.filename = compiler.modules[i].name + '.ts';
            fServer.content = '';// compiler.modules[i].service;
            po.value.push(fServer);
        }
        //console.log(po);
        this.http.post('pcr.php', po)
            .success(this.onResovleCode)
            .error(this.onError);
    }
    public onResovleCode = (code: string[]) => {
        //console.log(code);
        var file = this.files[this.compilerIndex];
        var compiler = file.compiler;
        var po = new PHPPostObj()
        po.method = 'Write';
        var filename = this.files[this.compilerIndex].name;
        var fClient = new FileBuiler();
        fClient.filename = filename.substr(0, filename.length - 3) + 'Client.ts';
        fClient.content = compiler.client;
        file.output.push(fClient.filename);
        po.value.push(fClient);
        for (var i: number = 0; i < compiler.modules.length; i++) {
            var fServer = new FileBuiler();
            fServer.filename = compiler.modules[i].name + '.ts';
            fServer.content = compiler.modules[i].implant(code[i], compiler.modules[i].name);
            po.value.push(fServer);
            file.output.push(fServer.filename);
        }
        file.status = 'compiled';
        //console.log(po);
        this.http.post('pcr.php', po)
            .success(this.onCompiled)
            .error(this.onError);
    }
    public onCompiled = (value: string) => {
        //console.log(value);
        this.files[this.compilerIndex].compiled = true;
        //this.scope.$apply();
        this.compilerIndex += 1;
        this.compileNext();
    }
}


//app.addController('rpc', RPCController);

//this file defines the UI for php.html.
class PHPCompileTask {
    public name: string;
    public compiled: boolean;
    public include: string[];
    public require: string[];
    public code: string;
    public status: string;
    public output: string[];
}
class PHPController {
    static $inject = ['$http', '$scope'];

    public test: string;
    public http: ng.IHttpService;
    public scope: ng.IScope;
    public root: Root;
    constructor(public $http: ng.IHttpService, public $scope: ng.IScope) {
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    public files: PHPCompileTask[];
    public scan = () => {
        var po = new PHPPostObj();
        po.method = 'ScanPHP';
        this.http.post('pcr.php', po)
            .success(this.onReceiveFiles);
    }
    public onReceiveFiles = (data: string[]) => {
        console.log(data);
        this.files = [];
        for (var i: number = 0; i < data.length; i++) {
            this.files.push({
                name: data[i], compiled: false, include: [], require:[], code: '', status: 'detected', output: []
            });
        }
    }
    public compilerIndex: number = -1;
    public compile = () => {
        for (var i: number = 0; i < this.files.length; i++) {
            this.files[i].output = [];
        }
        //needs to get file from the server and compile them;
        if (this.compilerIndex < 0) {
            this.compilerIndex = 0;
            this.compileNext();
        }
    }
    public compileNext = () => {
        if (this.files[this.compilerIndex]) {
            var file = this.files[this.compilerIndex];
            this.http.get(file.name)
                .success(this.onReceiveCode);
        } else {
            //end of compiling
            this.compilerIndex = -1;
        }
    }
    public onError = (data: any, status: number, headers: ng.IHttpHeadersGetter, config: ng.IRequestConfig): void => {
        console.log(headers);
        console.log('status: ' + status.toString());
    }

    public onReceiveCode = (code: string) => {
        //console.log(code);
        var mi = CompilerPattern.ptnPHPInclude.Match(code);
        var includevalues = mi.groups[2];
        //var requirevalues = mi.groups[5];
        var file: PHPCompileTask = this.files[this.compilerIndex];
        file.include = [];
        file.code = code;
        //console.log('onReceiveCode' + includevalues);
        if (includevalues) {
            if (includevalues.length > 0) {
                var mcIncludes = CompilerPattern.ptnIncludeFile.Matches(includevalues);
                for (var i: number = 0; i < mcIncludes.length; i++) {
                    //php includes.push(mcIncludes[i].groups[1]);
                    file.include.push(mcIncludes[i].groups[1])
                }
            }
            //here we need to get all the dependent files and check the modules
            var po = new PHPPostObj();
            po.method = 'Get';
            for (var i: number = 0; i < file.include.length; i++) {
                var fb = new FileBuiler();
                fb.filename = file.include[i] + '.ts';
                fb.content = '';
                po.value.push(fb);
            }
            for (var i: number = 0; i < file.require.length; i++) {
                var fb = new FileBuiler();
                fb.filename = file.include[i] + '.ts'; 
                fb.content = '';
                po.value.push(fb);
            }
            this.http.post('pcr.php', po)
                .success(this.onReceiveIncludes)
                .error(this.onError);
        }
        else {
            console.log('start compile');
            file.include = [];
            var compiler = new Pratphall.BrowserCompiler();
            var op = new Pratphall.PhpEmitOptions();
            var compiledcode: string;
            op.comments = true;
            op.indent = '\t';
            op.useElseif = true;
            op.openingFunctionBraceNextLine = true;
            op.openingTypeBraceOnNextLine = true;
            compiler.compile(op, 'module _PhpGeneralNamespaceEnforcingModule { }\n' + file.code, this.onCompiled);
        }
    }
    public onReceiveIncludes = (code: string[]) => {
        console.log(code);
        var file: PHPCompileTask = this.files[this.compilerIndex];
        var compiler = new Pratphall.BrowserCompiler();
        var op = new Pratphall.PhpEmitOptions();
        var compiledcode: string;
        op.comments = true;
        op.indent = '\t';
        op.useElseif = true;
        op.openingFunctionBraceNextLine = true;
        op.openingTypeBraceOnNextLine = true;
        for (var i: number = 0; i < code.length; i++) {
            var mt = /[\w\/]/.Match(code[i]);
            code[i] = code[i].substr(mt.index);
        }
        var prepared = code.join('\n') + '\n module _PhpGeneralNamespaceEnforcingModule { }\n' + file.code;
        console.log(code[0].charCodeAt(0));
        console.log(prepared);
        
        compiler.compile(op, prepared, this.onCompiled);
    }
    public onCompiled = (compiled: string, errors: any[], warnings: any[]) => {
        var file: PHPCompileTask = this.files[this.compilerIndex];
        var po = new PHPPostObj()
        po.method = 'Write';
        //work out the //php and include
        var builder: string[] = [];
        builder.push('<?php\n');
        var phpfile = new FileBuiler()
        phpfile.filename = this.files[this.compilerIndex].name.replace('.ts', '.php');
        builder.push(compiled.split(/namespace\s+[\w]+\s+\{\s*\}/g).join(''));
        builder.push('?>');
        phpfile.content = builder.join('');
        file.status = 'compiled';
        file.output.push(phpfile.filename);
        po.value.push(phpfile);
        console.log(po);
        this.http.post('pcr.php', po)
            .success(this.onWritten)
            .error(this.onError);
    }
    public onWritten = (value: string) => {
        console.log(value);
        this.files[this.compilerIndex].compiled = true;
        //this.scope.$apply();
        this.compilerIndex += 1;
        this.compileNext();
    }
}

//app.addController('php', PHPController);

class Root {
    static $inject = ['$http', '$scope'];
    public http: ng.IHttpService;
    public scope: ng.IScope;
    public cf: CFController;
    public rpc: RPCController; 
    public php: PHPController;
    constructor(public $http: ng.IHttpService, public $scope: ng.IScope) {
        this.http = $http;
        this.scope = $scope;
        this.cf = new CFController($http, $scope);
        this.rpc = new RPCController($http, $scope);
        this.php = new PHPController($http, $scope);
        this.cf.root = this;
        this.rpc.root = this;
        this.php.root = this;
    }

}
app.addController('root', Root);