﻿class MainController {
    static $inject = ngInject(ns.http, ns.scope);
    public result: string;
    constructor($http: ng.IHttpService, $scope: ng.IScope) {
        RPC.http = $http;
        this.result = 'angular is working!';
    }
    public click = () => {
        loginClient.login.login('hello', this.onLoginSuccess);
    }
    public onLoginSuccess = (data: boolean) => {
        console.log(data);
        this.result = data.toString();
    }
    public onError = (data) => {

    }
}

var app = new ngstd.AngularModule('app', []); 

app.addController('main', MainController);

