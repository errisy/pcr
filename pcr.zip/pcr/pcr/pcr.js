/**
 * This class is for the definition of MySQL database from Typescript;
 * Basically, it will generate queries for accessing proper type of database;
 * Each access must be verified by username and password check.
 */
var cf = (function () {
    function cf() {
    }
    /**
     * Define a variable char with speicific length;
     * @param length
     */
    cf.VarChar = function (length) {
        return '';
    };
    ;
    /**
     * Define a text field in MySQL
     */
    cf.Text = function () {
        return '';
    };
    /**
     * Define a decimal number with specific length and scale;
     * @param length
     * @param scale
     */
    cf.Decimal = function (length, scale) {
        return 0;
    };
    ;
    /**
     * Define an int number;
     */
    cf.Int = function () {
        return 0;
    };
    cf.Bool = function () {
        return false;
    };
    /**
     * Define a small int;
     */
    cf.SmallInt = function () {
        return 0;
    };
    cf.TinyInt = function () {
        return 0;
    };
    cf.BigInt = function () {
        return 0;
    };
    cf.Date = function () {
        return new Date();
    };
    cf.Time = function () {
        return new Date();
    };
    cf.DateTime = function () {
        return new Date();
    };
    cf.TimeStamp = function () {
        return new Date();
    };
    /**
     * Define how a field is linked to other classes;
     * @param keyField You must use '(new Classname).property' expression to assign this;
     */
    cf.ArrayOf = function (keyField) {
        return null;
    };
    cf.ReferenceOf = function (keyField) {
        return null;
    };
    cf.MD5Password = function () {
        return cf;
    };
    /**
     * By speicify the login method, the php side will create a login method for you to call;
     * However, in order to simplify server logic, we will not create a very complex php query script with built-in login verification.
     * @param info
     */
    cf.Username = function () {
        return cf;
    };
    cf.Password = function () {
        return cf;
    };
    /**
     * It allows the creation of a new kind of table by the name of that system.
     * @param name
     */
    cf.SubTable = function (name) {
        return '';
    };
    cf.PrimaryKey = function () {
        return cf;
    };
    cf.Unique = function () {
        return cf;
    };
    cf.ZeroFill = function () {
        return cf;
    };
    cf.AutoIncrement = function () {
        return cf;
    };
    cf.NotNull = function () {
        return cf;
    };
    cf.DefaultString = function (value) {
        return cf;
    };
    cf.DefaultNumber = function (value) {
        return cf;
    };
    cf.Verify = function (entity) {
        return cf;
    };
    cf.Login = function () {
        return function (http, entity) { return true; };
    };
    cf.Update = function () {
        return function (http, entity) { return true; };
    };
    cf.UpdateArray = function () {
        return function (http, entity) { return true; };
    };
    return cf;
}());
var CFCompiler = (function () {
    function CFCompiler(code) {
        this.databases = [];
        var arr = [];
        var codeSections = SectionDivider.Divide(code, CFDatabase.ptnModule);
        for (var i = 0; i < codeSections.length; i++) {
            var mt = CFDatabase.ptnModule.Match(codeSections[i]);
            var mDatabase = new CFDatabase(codeSections[i]);
            arr.push(mDatabase);
        }
        this.code = code;
        var mc = StdPatterns.ptnModule.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _database = new CFDatabase(this.code.substring(begin, end));
            _database.name = mt.groups[2];
            _database.begin = begin;
            _database.parent = this;
            this.databases.push(_database);
        }
    }
    return CFCompiler;
}());
var CFDatabase = (function () {
    function CFDatabase(value) {
        this.tables = [];
        //analyze value to obtain the name of table;
        this.code = value;
        var mc = CompilerPattern.ptnService.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _table = new CFTable(this.code.substring(begin, end));
            _table.parent = this;
            _table.name = mt.groups[4];
            _table.begin = begin;
            this.tables.push(_table);
        }
    }
    CFDatabase.prototype.getDatabaseCreateQuery = function () {
        var CreateQueries = [];
        for (var i = 0; i < this.tables.length; i++) {
            CreateQueries.push(this.tables[i].create);
        }
        return CreateQueries.join(';');
    };
    Object.defineProperty(CFDatabase.prototype, "ts", {
        get: function () {
            var builder = [];
            builder.push('module ' + this.name + 'Data {\n');
            for (var i = 0; i < this.tables.length; i++) {
                builder.push(this.tables[i].ts);
            }
            //codes for create and drop tables;
            builder.push('\texport class TableCreation {\n');
            for (var i = 0; i < this.tables.length; i++) {
                builder.push('\t\tpublic ', this.name, '_', this.tables[i].name, ':string = "', this.tables[i].create, '";\n');
            }
            builder.push('\t}\n');
            builder.push('}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    CFDatabase.ptnModule = /^\s*module\s+(\w+)\s*\{/g;
    return CFDatabase;
}());
var CFTable = (function () {
    function CFTable(value) {
        this.fields = [];
        //analyze value to obtain the name of table;
        this.code = value;
        var fieldSections = SectionDivider.DivideWith(this.code, /(^\s*|(;)[\s^\n]*\n[\s^\n]*)/g, 2);
        //console.log(fieldSections);
        for (var j = 0; j < fieldSections.length; j++) {
            //var mt = CFDatabase.ptnModule.Match(fieldSections[i]);
            var mt;
            var fieldcode = fieldSections[j];
            console.log(fieldcode);
            for (var i = 0; i < FieldModels.length; i++) {
                var fm = FieldModels[i];
                if (fm.pattern.IsMatch(fieldcode)) {
                    //console.log(fieldcode);
                    var field = new CFField(fieldcode);
                    var mt = fm.pattern.Match(fieldcode);
                    fm.setFeild(mt, field);
                    //this.Name = mt.groups[3];
                    //this.Model = fm;
                    //this.Attributes = mt.groups[4];
                    //this.FieldType = mt.groups[6];
                    //if (mt.groups[7]) this.Length = Number(mt.groups[7]);
                    //if (mt.groups[8]) this.Scale = Number(mt.groups[8]);
                    if (CFField.ptnPrimaryKey.IsMatch(field.attributes)) {
                        console.log('PrimaryKey ' + field.name);
                        field.isPrimaryKey = true;
                        field.isNotNull = true;
                    }
                    if (CFField.ptnNotNull.IsMatch(field.attributes)) {
                        field.isNotNull = true;
                    }
                    if (CFField.ptnAutoIncrement.IsMatch(field.attributes) && fm.canAutoIncrement) {
                        field.isAutoIncrement = true;
                    }
                    if (fm.canDefaultString)
                        if (CFField.ptnDefaultString.IsMatch(field.attributes)) {
                            var md = CFField.ptnDefaultString.Match(field.attributes);
                            field.hasDefaultValue = true;
                            field.defaultValue = md.groups[1];
                            console.log('default string: ' + field.defaultValue);
                        }
                    if (fm.canDefaultNumber)
                        if (CFField.ptnDefaultNumber.IsMatch(field.attributes)) {
                            var md = CFField.ptnDefaultNumber.Match(field.attributes);
                            field.hasDefaultValue = true;
                            field.defaultValue = md.groups[1];
                            console.log('default number: ' + field.defaultValue);
                        }
                    console.log(field);
                    this.fields.push(field);
                }
            }
        }
    }
    Object.defineProperty(CFTable.prototype, "create", {
        get: function () {
            var builder = [];
            builder.push('Create Table ', this.parent.name, '.', this.name, '(');
            var primaryKeyField;
            var defs = [];
            for (var i = 0; i < this.fields.length; i++) {
                //the first primary key field is valid.
                if (!primaryKeyField && this.fields[i].isPrimaryKey)
                    primaryKeyField = this.fields[i];
                defs.push(this.fields[i].definition);
            }
            if (primaryKeyField) {
                defs.push("Primary Key (" + primaryKeyField.name + ')');
            }
            builder.push(defs.join(', '));
            builder.push(');');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFTable.prototype, "ts", {
        get: function () {
            var builder = [];
            builder.push('\texport class ' + this.name + '{\n');
            for (var i = 0; i < this.fields.length; i++) {
                builder.push(this.fields[i].ts);
            }
            builder.push('\t}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFTable.prototype, "dts", {
        get: function () {
            return '';
        },
        enumerable: true,
        configurable: true
    });
    CFTable.ptnTable = /(^|\n)\s*(export\s+|)class\s+(\w+)\s*\{/g;
    return CFTable;
}());
var FieldModel = (function () {
    function FieldModel() {
    }
    return FieldModel;
}());
var FieldModels = [
    {
        name: 'VarChar',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'string'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*string\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(VarChar)\s*\(\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Decimal',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); f.scale = Number(m.groups[8]); },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Decimal)\s*\(\s*(\d+)\s*\,\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Int',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Int)\s*\(\s*\)\s*;/g
    },
    {
        name: 'BigInt',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(BigInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'TinyInt',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(TinyInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Bool',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'number'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Bool)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Text',
        setFeild: function (m, f) { f.model = f.model; f.tsType = 'string'; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*string\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Text)\s*\(\s*\)\s*;/g
    }
];
var CFField = (function () {
    function CFField(value) {
        this.code = value;
    }
    Object.defineProperty(CFField.prototype, "definition", {
        get: function () {
            //console.log('Name: ' + this.Name);
            //console.log(this.FieldType);
            switch (this.fieldType) {
                case 'VarChar':
                    //console.log('case: VarChar');
                    return this.name
                        + ' VARCHAR(' + this.length + ')'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue + '\'' : '');
                case 'Int':
                    return this.name
                        + ' Int '
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.isAutoIncrement) ? ' AUTO_INCREMENT ' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Decimal':
                    return this.name
                        + ' Deciaml(' + this.length + ',' + this.scale + ')'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'TinyInt':
                    return this.name
                        + ' TinyInt'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'BigInt':
                    return this.name
                        + ' BigInt'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Bool':
                    return this.name
                        + ' TinyInt(1)'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Text':
                    return this.name
                        + ' Text'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue + '\'' : '\'');
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFField.prototype, "ts", {
        get: function () {
            return '\t\tpublic ' + this.name + ':' + this.tsType + ';\n';
        },
        enumerable: true,
        configurable: true
    });
    CFField.ptnPrimaryKey = /PrimaryKey\s*\(\s*\)/g;
    CFField.ptnNotNull = /NotNull\s*\(\s*\)/g;
    CFField.ptnAutoIncrement = /AutoIncrement\s*\(\s*\)/g;
    CFField.ptnDefaultString = /DefaultString\s*\(\s*(('|")[^']+('|"))\s*\)/g;
    CFField.ptnDefaultNumber = /DefaultNumber\s*\(\s*((\-|)[\d\.]+)\s*\)/g;
    return CFField;
}());
//rpc
//this file defines classes that can convert interfaces to PHP based remote procedure calls;
var RPCCompiler = (function () {
    function RPCCompiler(value) {
        this.modules = [];
        this.references = [];
        console.log(value);
        this.code = value;
        var mi = CompilerPattern.ptnRPCInclude.Match(value);
        var includevalues = mi.groups[2];
        console.log('rpc includes:' + value);
        if (includevalues)
            if (includevalues.length > 0) {
                var includes = CompilerPattern.ptnIncludeFile.Matches(includevalues);
                for (var i = 0; i < includes.length; i++) {
                    var inc = includes[i];
                    this.references.push(inc.groups[1]);
                }
            }
        var mc = StdPatterns.ptnModule.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _module = new RPCModule(this.code.substring(begin, end));
            _module.name = mt.groups[2];
            _module.begin = begin;
            _module.parent = this;
            this.modules.push(_module);
        }
        console.log(this.modules);
    }
    Object.defineProperty(RPCCompiler.prototype, "client", {
        get: function () {
            var builder = [];
            for (var i = 0; i < this.modules.length; i++) {
                builder.push(this.modules[i].client);
            }
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCCompiler.prototype, "service", {
        get: function () {
            var builder = [];
            for (var i = 0; i < this.modules.length; i++) {
                builder.push(this.modules[i].service);
            }
            return builder.join('\n');
        },
        enumerable: true,
        configurable: true
    });
    return RPCCompiler;
}());
var RPCModule = (function () {
    function RPCModule(value) {
        var _this = this;
        this.services = [];
        this.implant = function (old, name) {
            name = name + 'Service';
            if (!old)
                return _this.service;
            var ptnAUTO = /\/\/\-\-\-AUTOGENERATED\sCODE\sBELOW/g;
            var mtAUTO = ptnAUTO.Match(old);
            var end;
            if (mtAUTO) {
                end = mtAUTO.index;
            }
            else {
                end = old.length;
            }
            var start;
            var mtPHP = CompilerPattern.ptnPHPInclude.Match(old);
            if (mtPHP) {
                start = mtPHP.length;
            }
            else {
                start = 0;
            }
            var mod = old.substring(start, end);
            var _oldModule;
            //the following codes will find out the module matching this name;
            console.log('mod code:');
            console.log(mod);
            var mc = StdPatterns.ptnModule.Matches(mod);
            for (var i = 0; i < mc.length; i++) {
                var mt = mc[i];
                var begin = mod.indexOf('{', mt.index) + 1;
                var end;
                if (mc[i + 1]) {
                    end = mod.lastIndexOf('}', mc[i + 1].index);
                }
                else {
                    end = mod.lastIndexOf('}', mod.length);
                }
                if (mt.groups[2] == name) {
                    _oldModule = new RPCModule(mod.substring(begin, end));
                    _oldModule.begin = begin;
                    _oldModule.name = name;
                }
            }
            if (_oldModule) {
                console.log('module found');
                var _insertions = _oldModule.update(_this);
                console.log(_insertions);
                _insertions.sort(Insertion.Compare);
                var index = 0;
                var builder = [];
                builder.push(_this.reference);
                for (var i = 0; i < _insertions.length; i++) {
                    console.log('Section ' + i.toString() + ' at ' + _insertions[i].index.toString() + ': ' + mod.substring(0, _insertions[i].index));
                    builder.push(mod.substring(index, _insertions[i].index));
                    console.log('Insertion ' + i.toString() + ': ' + _insertions[i].value);
                    builder.push(_insertions[i].value);
                    index = _insertions[i].index;
                }
                if (_insertions.length > 0) {
                    console.log('final: ' + mod.substring(_insertions[_insertions.length - 1].index, mod.length));
                    builder.push(mod.substring(index, mod.length));
                }
                else {
                    builder.push(mod);
                }
                builder.push(_this.dispatcher);
                return builder.join('');
            }
            else {
                console.log('module not found');
                return _this.service;
            }
        };
        this.update = function (updated) {
            console.log(_this);
            console.log(updated);
            var _insertions = [];
            var newServices = [];
            for (var i = 0; i < updated.services.length; i++) {
                if (_this.hasService(updated.services[i])) {
                    console.log('has Service: ' + updated.services[i].name);
                    var _service = _this.getService(updated.services[i].name);
                    _insertions.push(_service.update(updated.services[i]));
                }
                else {
                    //put the new services in the array, they will be added at the end of the update;
                    console.log('not has Service: ' + updated.services[i].name);
                    newServices.push(updated.services[i]);
                }
            }
            var builder = [];
            for (var i = 0; i < newServices.length; i++) {
                builder.push('\n', newServices[i].service);
            }
            if (newServices.length > 0) {
            }
            var _insertion = new Insertion();
            _insertion.index = _this.begin;
            _insertion.value = builder.join('');
            _insertions.push(_insertion);
            return _insertions;
        };
        this.hasService = function (service) {
            for (var i = 0; i < _this.services.length; i++) {
                if (_this.services[i].name == service.name)
                    return true;
            }
            return false;
        };
        this.getService = function (name) {
            for (var i = 0; i < _this.services.length; i++) {
                if (_this.services[i].name == name)
                    return _this.services[i];
            }
            return null;
        };
        this.code = value;
        var mc = CompilerPattern.ptnService.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _service = new RPCService(this.code.substring(begin, end));
            _service.parent = this;
            _service.name = mt.groups[4];
            _service.begin = begin;
            this.services.push(_service);
        }
    }
    Object.defineProperty(RPCModule.prototype, "client", {
        get: function () {
            var builder = [];
            builder.push('module ', this.name, 'Client', ' {\n');
            for (var i = 0; i < this.services.length; i++) {
                builder.push(this.services[i].client);
            }
            builder.push('\n}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCModule.prototype, "reference", {
        get: function () {
            var refbuilder = [];
            refbuilder.push('\'rpcdef\'');
            console.log('references: ');
            console.log(this.parent.references);
            for (var i = 0; i < this.parent.references.length; i++) {
                refbuilder.push('\'' + this.parent.references[i] + '\'');
            }
            return '//php include ' + refbuilder.join(' ') + ' \n';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCModule.prototype, "service", {
        get: function () {
            var builder = [];
            /*
    var postInput = file_get_contents("php://input");
    var jsonObject: rpc = json_decode(postInput);
    //call dispatcher;
    switch (jsonObject.service) {
    
    }
            */
            builder.push(this.reference);
            builder.push('module ', this.name, 'Service', ' {\n');
            for (var i = 0; i < this.services.length; i++) {
                builder.push(this.services[i].service);
            }
            builder.push('\n}\n');
            builder.push(this.dispatcher);
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCModule.prototype, "dispatcher", {
        get: function () {
            var builder = [];
            builder.push('//---AUTOGENERATED CODE BELOW: typescript dispatcher for php, please do not modify any code blow \n');
            builder.push('var postInput = file_get_contents("php://input");\n');
            builder.push('var jsonObject: rpc = json_decode(postInput);\n');
            //builder.push('//Dispatch serices and calls to object;\n');
            builder.push('switch (jsonObject.service) {\n');
            for (var i = 0; i < this.services.length; i++) {
                builder.push(this.services[i].dispatcher);
            }
            builder.push('}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    return RPCModule;
}());
var RPCService = (function () {
    function RPCService(value) {
        var _this = this;
        this.methods = [];
        this.update = function (updated) {
            var newMethods = [];
            for (var i = 0; i < updated.methods.length; i++) {
                if (_this.hasMethod(updated.methods[i])) {
                    var _method = _this.getMethod(updated.methods[i].name);
                    if (!_method.isIndentical(updated.methods[i])) {
                        //if the new method is different from the old one, we still need to insert the new methods;
                        newMethods.push(updated.methods[i]);
                    }
                }
                else {
                    //put the new methods in the array, they will be added at the end of the update;
                    newMethods.push(updated.methods[i]);
                }
            }
            var builder = [];
            for (var i = 0; i < newMethods.length; i++) {
                builder.push('\n', newMethods[i].service);
            }
            //if (newMethods.length > 0) builder.push('\n');
            var _insertion = new Insertion();
            _insertion.index = _this.parent.begin + _this.begin;
            _insertion.value = builder.join('');
            return _insertion;
        };
        this.hasMethod = function (method) {
            for (var i = 0; i < _this.methods.length; i++) {
                if (_this.methods[i].name == method.name)
                    return true;
            }
            return false;
        };
        this.getMethod = function (name) {
            for (var i = 0; i < _this.methods.length; i++) {
                if (_this.methods[i].name == name)
                    return _this.methods[i];
            }
            return null;
        };
        this.code = value;
        var mc = StdPatterns.ptnInterfaceMethod.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var _method = new RPCMethod(mt.groups[2]);
            _method.name = mt.groups[1];
            _method.returnType = mt.groups[8].split(' ').join('');
            _method.parent = this;
            this.methods.push(_method);
        }
    }
    Object.defineProperty(RPCService.prototype, "client", {
        get: function () {
            var builder = [];
            builder.push('  export class ', this.name, ' {\n');
            for (var i = 0; i < this.methods.length; i++) {
                builder.push(this.methods[i].client);
            }
            builder.push('  }\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCService.prototype, "dispatcher", {
        get: function () {
            var builder = [];
            /*
        case 'newcall':
            var serviceObject = new newcallService();
            switch (jsonObject.method) {
    
            }
            break;
            */
            builder.push('    case \'', this.name, '\':\n');
            builder.push('        var ', this.parent.name, '_', this.name, ' = new ', this.parent.name, 'Service.', this.name, '();\n');
            builder.push('        switch (jsonObject.method) {\n');
            for (var i = 0; i < this.methods.length; i++) {
                builder.push(this.methods[i].dispatcher);
            }
            builder.push('        }\n');
            builder.push('        break;\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCService.prototype, "service", {
        get: function () {
            var builder = [];
            builder.push('  export class ', this.name, ' {\n');
            for (var i = 0; i < this.methods.length; i++) {
                builder.push(this.methods[i].service);
            }
            builder.push('  }\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    return RPCService;
}());
var RPCMethod = (function () {
    function RPCMethod(value) {
        var _this = this;
        this.parameters = [];
        this.isIndentical = function (updated) {
            //Check if the method is the same one;
            if (_this.name != updated.name)
                return false;
            if (_this.returnType != updated.returnType)
                return false;
            if (_this.parameters.length != updated.parameters.length)
                return false;
            for (var i = 0; i < _this.parameters.length; i++) {
                if (_this.parameters[i].service != updated.parameters[i].service)
                    return false;
            }
            return true;
        };
        this.code = value;
        var mc = StdPatterns.ptnParameter.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var _parameter = new RPCParameter();
            _parameter.name = mt.groups[1];
            _parameter.type = mt.groups[2].split(' ').join('');
            this.parameters.push(_parameter);
        }
    }
    Object.defineProperty(RPCMethod.prototype, "client", {
        get: function () {
            var builder = [];
            var pmNames = [];
            builder.push('      public static ', this.name, ' (');
            for (var i = 0; i < this.parameters.length; i++) {
                builder.push(this.parameters[i].client);
                builder.push(', ');
                pmNames.push(this.parameters[i].name);
            }
            builder.push('\n');
            builder.push('          _SuccessCallback: ng.IHttpPromiseCallback<', this.returnType, '>');
            builder.push(', \n');
            builder.push('          _ErrorCallback?: ng.IHttpPromiseCallback<', this.returnType, '>');
            builder.push(') {\n');
            builder.push('          var _RemoteProcedureCallObject: rpc = {\n');
            builder.push('                  service: \'', this.parent.name, '\', method: \'', this.name, '\', parameters: [', pmNames.join(', '), ']\n');
            builder.push('              }\n');
            builder.push('          RPC.http.post(\'', this.parent.parent.name, '.php\', _RemoteProcedureCallObject)\n');
            builder.push('              .success(_SuccessCallback)\n');
            builder.push('              .error(_ErrorCallback);\n');
            builder.push('      }\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCMethod.prototype, "dispatcher", {
        get: function () {
            var builder = [];
            /*
                case 'query':
                    var remoteCallResult = serviceObject.query(jsonObject.parameters[0]);
                    echo(json_encode(remoteCallResult));
            */
            builder.push('          case \'', this.name, '\':\n');
            builder.push('              var ', this.parent.parent.name, '_', this.parent.name, '_', this.name, 'Result = ', this.parent.parent.name, '_', this.parent.name, '.', this.name, '(');
            var pmValues = [];
            for (var i = 0; i < this.parameters.length; i++) {
                pmValues.push('<' + this.parameters[i].type + '>(jsonObject.parameters[' + i.toString() + '])');
            }
            builder.push(pmValues.join(', '));
            builder.push(');\n');
            builder.push('              echo(json_encode(', this.parent.parent.name, '_', this.parent.name, '_', this.name, 'Result));\n');
            builder.push('              break;\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCMethod.prototype, "service", {
        get: function () {
            var builder = [];
            var pmNames = [];
            builder.push('      public ', this.name, ' (');
            for (var i = 0; i < this.parameters.length; i++) {
                pmNames.push(this.parameters[i].client);
            }
            builder.push(pmNames.join(', '));
            builder.push('):', this.returnType, '{\n');
            builder.push('          return null;\n');
            builder.push('      }\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    return RPCMethod;
}());
var RPCParameter = (function () {
    function RPCParameter() {
    }
    Object.defineProperty(RPCParameter.prototype, "client", {
        get: function () {
            return [this.name, ':', this.type].join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RPCParameter.prototype, "service", {
        get: function () {
            return [this.name, ':', this.type].join('');
        },
        enumerable: true,
        configurable: true
    });
    return RPCParameter;
}());
var app = new ngstd.AngularModule('pcr', []);
//this file defines the UI for php.html.
var CFCompileTask = (function () {
    function CFCompileTask() {
    }
    return CFCompileTask;
}());
var CFController = (function () {
    function CFController($http, $scope) {
        var _this = this;
        this.$http = $http;
        this.$scope = $scope;
        this.scan = function () {
            var po = new PHPPostObj();
            po.method = 'ScanCF';
            _this.http.post('pcr.php', po)
                .success(_this.onReceiveFiles);
        };
        this.onReceiveFiles = function (data) {
            console.log(data);
            _this.files = [];
            for (var i = 0; i < data.length; i++) {
                _this.files.push({
                    name: data[i], compiled: false, include: '', status: 'detected', output: []
                });
            }
        };
        this.compilerIndex = -1;
        this.compile = function () {
            for (var i = 0; i < _this.files.length; i++) {
                _this.files[i].output = [];
            }
            //needs to get file from the server and compile them;
            if (_this.compilerIndex < 0) {
                _this.compilerIndex = 0;
                _this.compileNext();
            }
        };
        this.compileNext = function () {
            if (_this.files[_this.compilerIndex]) {
                var file = _this.files[_this.compilerIndex];
                _this.http.get(file.name)
                    .success(_this.onReceiveCode);
            }
            else {
                //end of compiling
                _this.compilerIndex = -1;
            }
        };
        this.onError = function (data, status, headers, config) {
            console.log(headers);
            console.log('status: ' + status.toString());
        };
        this.onReceiveCode = function (code) {
            var compiler = new CFCompiler(code);
            var file = _this.files[_this.compilerIndex];
            var po = new PHPPostObj();
            po.method = 'Write';
            //work out the //php and include
            var builder = [];
            //builder.push('<?php\n');
            //var phpincludes: string[] = [];
            for (var i = 0; i < compiler.databases.length; i++) {
                builder.push(compiler.databases[i].ts);
            }
            //builder.push('?>');
            var phpfile = new FileBuiler();
            phpfile.filename = file.name.replace('.ts', 'Data.ts');
            phpfile.content = builder.join('');
            file.status = 'compiled';
            file.output.push(phpfile.filename);
            po.value.push(phpfile);
            console.log(po);
            _this.http.post('pcr.php', po)
                .success(_this.onWritten)
                .error(_this.onError);
        };
        this.onWritten = function (value) {
            console.log(value);
            _this.files[_this.compilerIndex].compiled = true;
            //this.scope.$apply();
            _this.compilerIndex += 1;
            _this.compileNext();
        };
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    CFController.$inject = ['$http', '$scope'];
    return CFController;
}());
//app.addController('cf', CFController);
var RPCCompileTask = (function () {
    function RPCCompileTask() {
    }
    return RPCCompileTask;
}());
var RPCController = (function () {
    function RPCController($http, $scope) {
        var _this = this;
        this.$http = $http;
        this.$scope = $scope;
        this.scan = function () {
            var po = new PHPPostObj();
            po.method = 'ScanRPC';
            _this.http.post('pcr.php', po)
                .success(_this.onReceiveFiles);
        };
        this.onReceiveFiles = function (data) {
            console.log(data);
            _this.files = [];
            for (var i = 0; i < data.length; i++) {
                _this.files.push({
                    name: data[i], compiled: false, compiler: null, status: 'detected', output: []
                });
            }
        };
        this.compilerIndex = -1;
        this.compile = function () {
            //clear all the existing file outputs
            for (var i = 0; i < _this.files.length; i++) {
                _this.files[i].output = [];
            }
            //needs to get file from the server and compile them;
            if (_this.compilerIndex < 0) {
                _this.compilerIndex = 0;
                _this.compileNext();
            }
        };
        this.compileNext = function () {
            if (_this.files[_this.compilerIndex]) {
                var file = _this.files[_this.compilerIndex];
                _this.http.get(file.name)
                    .success(_this.onReceiveCode);
            }
            else {
                //end of compiling
                _this.compilerIndex = -1;
                _this.root.php.scan();
            }
        };
        this.onError = function (data, status, headers, config) {
            console.log(headers);
            console.log('status: ' + status.toString());
        };
        this.onReceiveCode = function (code) {
            var compiler = new RPCCompiler(code);
            _this.files[_this.compilerIndex].compiler = compiler;
            var po = new PHPPostObj();
            po.method = 'Get';
            var filename = _this.files[_this.compilerIndex].name;
            //var fClient = new FileBuiler();
            //fClient.filename = filename.substr(0,filename.length-3) + 'Client.ts';
            //fClient.content = compiler.client;
            //po.value.push(fClient);
            for (var i = 0; i < compiler.modules.length; i++) {
                var fServer = new FileBuiler();
                fServer.filename = compiler.modules[i].name + '.ts';
                fServer.content = ''; // compiler.modules[i].service;
                po.value.push(fServer);
            }
            //console.log(po);
            _this.http.post('pcr.php', po)
                .success(_this.onResovleCode)
                .error(_this.onError);
        };
        this.onResovleCode = function (code) {
            //console.log(code);
            var file = _this.files[_this.compilerIndex];
            var compiler = file.compiler;
            var po = new PHPPostObj();
            po.method = 'Write';
            var filename = _this.files[_this.compilerIndex].name;
            var fClient = new FileBuiler();
            fClient.filename = filename.substr(0, filename.length - 3) + 'Client.ts';
            fClient.content = compiler.client;
            file.output.push(fClient.filename);
            po.value.push(fClient);
            for (var i = 0; i < compiler.modules.length; i++) {
                var fServer = new FileBuiler();
                fServer.filename = compiler.modules[i].name + '.ts';
                fServer.content = compiler.modules[i].implant(code[i], compiler.modules[i].name);
                po.value.push(fServer);
                file.output.push(fServer.filename);
            }
            file.status = 'compiled';
            //console.log(po);
            _this.http.post('pcr.php', po)
                .success(_this.onCompiled)
                .error(_this.onError);
        };
        this.onCompiled = function (value) {
            //console.log(value);
            _this.files[_this.compilerIndex].compiled = true;
            //this.scope.$apply();
            _this.compilerIndex += 1;
            _this.compileNext();
        };
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    RPCController.$inject = ['$http', '$scope'];
    return RPCController;
}());
//app.addController('rpc', RPCController);
//this file defines the UI for php.html.
var PHPCompileTask = (function () {
    function PHPCompileTask() {
    }
    return PHPCompileTask;
}());
var PHPController = (function () {
    function PHPController($http, $scope) {
        var _this = this;
        this.$http = $http;
        this.$scope = $scope;
        this.scan = function () {
            var po = new PHPPostObj();
            po.method = 'ScanPHP';
            _this.http.post('pcr.php', po)
                .success(_this.onReceiveFiles);
        };
        this.onReceiveFiles = function (data) {
            console.log(data);
            _this.files = [];
            for (var i = 0; i < data.length; i++) {
                _this.files.push({
                    name: data[i], compiled: false, include: [], require: [], code: '', status: 'detected', output: []
                });
            }
        };
        this.compilerIndex = -1;
        this.compile = function () {
            for (var i = 0; i < _this.files.length; i++) {
                _this.files[i].output = [];
            }
            //needs to get file from the server and compile them;
            if (_this.compilerIndex < 0) {
                _this.compilerIndex = 0;
                _this.compileNext();
            }
        };
        this.compileNext = function () {
            if (_this.files[_this.compilerIndex]) {
                var file = _this.files[_this.compilerIndex];
                _this.http.get(file.name)
                    .success(_this.onReceiveCode);
            }
            else {
                //end of compiling
                _this.compilerIndex = -1;
            }
        };
        this.onError = function (data, status, headers, config) {
            console.log(headers);
            console.log('status: ' + status.toString());
        };
        this.onReceiveCode = function (code) {
            //console.log(code);
            var mi = CompilerPattern.ptnPHPInclude.Match(code);
            var includevalues = mi.groups[2];
            //var requirevalues = mi.groups[5];
            var file = _this.files[_this.compilerIndex];
            file.include = [];
            file.code = code;
            //console.log('onReceiveCode' + includevalues);
            if (includevalues) {
                if (includevalues.length > 0) {
                    var mcIncludes = CompilerPattern.ptnIncludeFile.Matches(includevalues);
                    for (var i = 0; i < mcIncludes.length; i++) {
                        //php includes.push(mcIncludes[i].groups[1]);
                        file.include.push(mcIncludes[i].groups[1]);
                    }
                }
                //here we need to get all the dependent files and check the modules
                var po = new PHPPostObj();
                po.method = 'Get';
                for (var i = 0; i < file.include.length; i++) {
                    var fb = new FileBuiler();
                    fb.filename = file.include[i] + '.ts';
                    fb.content = '';
                    po.value.push(fb);
                }
                for (var i = 0; i < file.require.length; i++) {
                    var fb = new FileBuiler();
                    fb.filename = file.include[i] + '.ts';
                    fb.content = '';
                    po.value.push(fb);
                }
                _this.http.post('pcr.php', po)
                    .success(_this.onReceiveIncludes)
                    .error(_this.onError);
            }
            else {
                console.log('start compile');
                file.include = [];
                var compiler = new Pratphall.BrowserCompiler();
                var op = new Pratphall.PhpEmitOptions();
                var compiledcode;
                op.comments = true;
                op.indent = '\t';
                op.useElseif = true;
                op.openingFunctionBraceNextLine = true;
                op.openingTypeBraceOnNextLine = true;
                compiler.compile(op, 'module _PhpGeneralNamespaceEnforcingModule { }\n' + file.code, _this.onCompiled);
            }
        };
        this.onReceiveIncludes = function (code) {
            console.log(code);
            var file = _this.files[_this.compilerIndex];
            var compiler = new Pratphall.BrowserCompiler();
            var op = new Pratphall.PhpEmitOptions();
            var compiledcode;
            op.comments = true;
            op.indent = '\t';
            op.useElseif = true;
            op.openingFunctionBraceNextLine = true;
            op.openingTypeBraceOnNextLine = true;
            for (var i = 0; i < code.length; i++) {
                var mt = /[\w\/]/.Match(code[i]);
                code[i] = code[i].substr(mt.index);
            }
            var prepared = code.join('\n') + '\n module _PhpGeneralNamespaceEnforcingModule { }\n' + file.code;
            console.log(code[0].charCodeAt(0));
            console.log(prepared);
            compiler.compile(op, prepared, _this.onCompiled);
        };
        this.onCompiled = function (compiled, errors, warnings) {
            var file = _this.files[_this.compilerIndex];
            var po = new PHPPostObj();
            po.method = 'Write';
            //work out the //php and include
            var builder = [];
            builder.push('<?php\n');
            var phpfile = new FileBuiler();
            phpfile.filename = _this.files[_this.compilerIndex].name.replace('.ts', '.php');
            builder.push(compiled.split(/namespace\s+[\w]+\s+\{\s*\}/g).join(''));
            builder.push('?>');
            phpfile.content = builder.join('');
            file.status = 'compiled';
            file.output.push(phpfile.filename);
            po.value.push(phpfile);
            console.log(po);
            _this.http.post('pcr.php', po)
                .success(_this.onWritten)
                .error(_this.onError);
        };
        this.onWritten = function (value) {
            console.log(value);
            _this.files[_this.compilerIndex].compiled = true;
            //this.scope.$apply();
            _this.compilerIndex += 1;
            _this.compileNext();
        };
        this.http = $http;
        this.scope = $scope;
        this.scan();
    }
    PHPController.$inject = ['$http', '$scope'];
    return PHPController;
}());
//app.addController('php', PHPController);
var Root = (function () {
    function Root($http, $scope) {
        this.$http = $http;
        this.$scope = $scope;
        this.http = $http;
        this.scope = $scope;
        this.cf = new CFController($http, $scope);
        this.rpc = new RPCController($http, $scope);
        this.php = new PHPController($http, $scope);
        this.cf.root = this;
        this.rpc.root = this;
        this.php.root = this;
    }
    Root.$inject = ['$http', '$scope'];
    return Root;
}());
app.addController('root', Root);
//# sourceMappingURL=pcr.js.map