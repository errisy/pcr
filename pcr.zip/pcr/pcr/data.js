//cf
var MarketSpecial;
(function (MarketSpecial) {
    var Company = (function () {
        function Company() {
            this.id = cf.PrimaryKey().AutoIncrement().Int();
            this.name = cf.VarChar(80);
            this.address = cf.VarChar(255);
            this.creation = cf.Date();
        }
        return Company;
    }());
    MarketSpecial.Company = Company;
})(MarketSpecial || (MarketSpecial = {}));
//# sourceMappingURL=data.js.map