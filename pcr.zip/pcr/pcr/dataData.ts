module MarketSpecialData {
	export class Company{
		public id:number;
		public name:string;
		public address:string;
	}
	export class TableCreation {
		public MarketSpecial_Company:string = "Create Table MarketSpecial.Company(id Int  Not Null AUTO_INCREMENT , name VARCHAR(80), address VARCHAR(255), Primary Key (id));";
	}
}
