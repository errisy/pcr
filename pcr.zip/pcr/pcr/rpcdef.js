// to be used by remote procedure calls
var rpc = (function () {
    function rpc() {
    }
    return rpc;
}());
//# sourceMappingURL=rpcdef.js.map