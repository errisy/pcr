var MainController = (function () {
    function MainController($http, $scope) {
        var _this = this;
        this.click = function () {
            loginClient.login.login('hello', _this.onLoginSuccess);
        };
        this.onLoginSuccess = function (data) {
            console.log(data);
            _this.result = data.toString();
        };
        this.onError = function (data) {
        };
        RPC.http = $http;
        this.result = 'angular is working!';
    }
    MainController.$inject = ngInject(ns.http, ns.scope);
    return MainController;
}());
var app = new ngstd.AngularModule('app', []);
app.addController('main', MainController);
//# sourceMappingURL=app.js.map