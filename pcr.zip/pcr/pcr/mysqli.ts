﻿//to be include for database access
module data {
    export class port {
        mySQLi: mysqli;
        /**
         * create the MySQLi connection with the server name, username, password and database;
         */
        constructor(server: string, username: string, password: string, database: string) {
            this.mySQLi = mysqli_connect(server, username, password, database);
        }
        /**
         * this initialize a MySQL statement query; you have to bind parameters with the 'bind_param' method of the statement;
         * @param sql
         */
        public createStatement(sql:string):mysqli_stmt {
            var stmt = this.mySQLi.stmt_init();
            stmt.prepare(sql);
            return stmt;
        }
        /**
         * this method will execute the mysql statement and reteurn the array of data objects, they are ready for json encoding;
         * @param stmt
         */
        public getDataObjects(stmt: mysqli_stmt): any[][] {
            stmt.execute();
            var list: any[] = array();
            var resultMetadata = stmt.result_metadata();
            
            if (resultMetadata) {
                var fields: any[] = array();
                var fieldmeta: MySQLiField;
                while (fieldmeta = mysqli_fetch_field(resultMetadata)) {
                    array_push(fields, fieldmeta.name);
                }
                mysqli_free_result(resultMetadata);
                var result = stmt.get_result();
                var row: any[];
                while (row = mysqli_fetch_array(result)) {
                    var obj = array();
                    for (var i: number = 0; i < sizeof(fields); i++) {
                        obj[fields[i]] = row[i];
                    }
                    array_push(list, obj);
                }
                mysqli_free_result(result);
            }
            return list;
        }
        /**
         * This method fetch the value from the key-value array object; it is very useful for the 'Count' query;
         * @param arr
         */
        public fetchFirstValue(arr: any[]): any {
            for (var key in <any[]>arr) {
                return arr[key];
            }
        }
        /**
         * This method fetch the key and value from the key-value array object; it is useful for specific type of queries;
         * @param arr
         */
        public fetchFirstKeyValuePair(arr: any[]): KeyValuePair {
            for (var key in <any[]>arr) {
                var kvp = new KeyValuePair();
                kvp.key = key;
                kvp.value = arr[key];
                return kvp;
            }
        }
        /**
         * Close the MySQLi connection at the end of the query;
         */
        __destruct() {
            this.mySQLi.close();
        }
    }

    class KeyValuePair {
        public key: string;
        public value: any;
    }

}