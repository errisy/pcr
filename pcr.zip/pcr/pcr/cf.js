/**
 * This class is for the definition of MySQL database from Typescript;
 * Basically, it will generate queries for accessing proper type of database;
 * Each access must be verified by username and password check.
 */
var cf = (function () {
    function cf() {
    }
    /**
     * Define a variable char with speicific length;
     * @param length
     */
    cf.VarChar = function (length) {
        return '';
    };
    ;
    /**
     * Define a text field in MySQL
     */
    cf.Text = function () {
        return '';
    };
    /**
     * Define a decimal number with specific length and scale;
     * @param length
     * @param scale
     */
    cf.Decimal = function (length, scale) {
        return 0;
    };
    ;
    /**
     * Define an int number;
     */
    cf.Int = function () {
        return 0;
    };
    cf.Bool = function () {
        return false;
    };
    /**
     * Define a small int;
     */
    cf.SmallInt = function () {
        return 0;
    };
    cf.TinyInt = function () {
        return 0;
    };
    cf.BigInt = function () {
        return 0;
    };
    cf.Date = function () {
        return new Date();
    };
    cf.Time = function () {
        return new Date();
    };
    cf.DateTime = function () {
        return new Date();
    };
    cf.TimeStamp = function () {
        return new Date();
    };
    /**
     * Define how a field is linked to other classes;
     * @param keyField You must use '(new Classname).property' expression to assign this;
     */
    cf.ArrayOf = function (keyField) {
        return null;
    };
    cf.ReferenceOf = function (keyField) {
        return null;
    };
    cf.MD5Password = function () {
        return cf;
    };
    /**
     * By speicify the login method, the php side will create a login method for you to call;
     * However, in order to simplify server logic, we will not create a very complex php query script with built-in login verification.
     * @param info
     */
    cf.Username = function () {
        return cf;
    };
    cf.Password = function () {
        return cf;
    };
    /**
     * It allows the creation of a new kind of table by the name of that system.
     * @param name
     */
    cf.SubTable = function (name) {
        return '';
    };
    cf.PrimaryKey = function () {
        return cf;
    };
    cf.Unique = function () {
        return cf;
    };
    cf.ZeroFill = function () {
        return cf;
    };
    cf.AutoIncrement = function () {
        return cf;
    };
    cf.NotNull = function () {
        return cf;
    };
    cf.DefaultString = function (value) {
        return cf;
    };
    cf.DefaultNumber = function (value) {
        return cf;
    };
    cf.Verify = function (entity) {
        return cf;
    };
    cf.Login = function () {
        return function (http, entity) { return true; };
    };
    cf.Update = function () {
        return function (http, entity) { return true; };
    };
    cf.UpdateArray = function () {
        return function (http, entity) { return true; };
    };
    return cf;
}());
var CFCompiler = (function () {
    function CFCompiler(code) {
        this.databases = [];
        var arr = [];
        var codeSections = SectionDivider.Divide(code, CFDatabase.ptnModule);
        for (var i = 0; i < codeSections.length; i++) {
            var mt = CFDatabase.ptnModule.Match(codeSections[i]);
            var mDatabase = new CFDatabase(codeSections[i]);
            arr.push(mDatabase);
        }
        this.code = code;
        var mc = StdPatterns.ptnModule.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _database = new CFDatabase(this.code.substring(begin, end));
            _database.name = mt.groups[2];
            _database.begin = begin;
            _database.parent = this;
            this.databases.push(_database);
        }
    }
    return CFCompiler;
}());
var CFDatabase = (function () {
    function CFDatabase(value) {
        this.tables = [];
        //analyze value to obtain the name of table;
        this.code = value;
        var mc = CompilerPattern.ptnService.Matches(this.code);
        for (var i = 0; i < mc.length; i++) {
            var mt = mc[i];
            var begin = this.code.indexOf('{', mt.index) + 1;
            var end;
            if (mc[i + 1]) {
                end = this.code.lastIndexOf('}', mc[i + 1].index);
            }
            else {
                end = this.code.lastIndexOf('}', this.code.length);
            }
            var _table = new CFTable(this.code.substring(begin, end));
            _table.parent = this;
            _table.name = mt.groups[4];
            _table.begin = begin;
            this.tables.push(_table);
        }
    }
    CFDatabase.prototype.getDatabaseCreateQuery = function () {
        var CreateQueries = [];
        for (var i = 0; i < this.tables.length; i++) {
            CreateQueries.push(this.tables[i].create);
        }
        return CreateQueries.join(';');
    };
    Object.defineProperty(CFDatabase.prototype, "php", {
        get: function () {
            var builder = [];
            builder.push('namespace ' + this.name + '{\n');
            for (var i = 0; i < this.tables.length; i++) {
                builder.push(this.tables[i].php);
            }
            //codes for create and drop tables;
            for (var i = 0; i < this.tables.length; i++) {
                builder.push('\t$', this.name, '_', this.tables[i].name, ' = "', this.tables[i].create, '";\n');
            }
            builder.push('}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    CFDatabase.ptnModule = /^\s*module\s+(\w+)\s*\{/g;
    return CFDatabase;
}());
var CFTable = (function () {
    function CFTable(value) {
        this.fields = [];
        //analyze value to obtain the name of table;
        this.code = value;
        var fieldSections = SectionDivider.DivideWith(this.code, /(^\s*|(;)[\s^\n]*\n[\s^\n]*)/g, 2);
        //console.log(fieldSections);
        for (var j = 0; j < fieldSections.length; j++) {
            //var mt = CFDatabase.ptnModule.Match(fieldSections[i]);
            var mt;
            var fieldcode = fieldSections[j];
            console.log(fieldcode);
            for (var i = 0; i < FieldModels.length; i++) {
                var fm = FieldModels[i];
                if (fm.pattern.IsMatch(fieldcode)) {
                    //console.log(fieldcode);
                    var field = new CFField(fieldcode);
                    var mt = fm.pattern.Match(fieldcode);
                    fm.setFeild(mt, field);
                    //this.Name = mt.groups[3];
                    //this.Model = fm;
                    //this.Attributes = mt.groups[4];
                    //this.FieldType = mt.groups[6];
                    //if (mt.groups[7]) this.Length = Number(mt.groups[7]);
                    //if (mt.groups[8]) this.Scale = Number(mt.groups[8]);
                    if (CFField.ptnPrimaryKey.IsMatch(field.attributes)) {
                        console.log('PrimaryKey ' + field.name);
                        field.isPrimaryKey = true;
                        field.isNotNull = true;
                    }
                    if (CFField.ptnNotNull.IsMatch(field.attributes)) {
                        field.isNotNull = true;
                    }
                    if (CFField.ptnAutoIncrement.IsMatch(field.attributes) && fm.canAutoIncrement) {
                        field.isAutoIncrement = true;
                    }
                    if (fm.canDefaultString)
                        if (CFField.ptnDefaultString.IsMatch(field.attributes)) {
                            var md = CFField.ptnDefaultString.Match(field.attributes);
                            field.hasDefaultValue = true;
                            field.defaultValue = md.groups[1];
                            console.log('default string: ' + field.defaultValue);
                        }
                    if (fm.canDefaultNumber)
                        if (CFField.ptnDefaultNumber.IsMatch(field.attributes)) {
                            var md = CFField.ptnDefaultNumber.Match(field.attributes);
                            field.hasDefaultValue = true;
                            field.defaultValue = md.groups[1];
                            console.log('default number: ' + field.defaultValue);
                        }
                    console.log(field);
                    this.fields.push(field);
                }
            }
        }
    }
    Object.defineProperty(CFTable.prototype, "create", {
        get: function () {
            var builder = [];
            builder.push('Create Table ', "'" + this.parent.name + "'.'" + this.name + "'", '(');
            var primaryKeyField;
            var defs = [];
            for (var i = 0; i < this.fields.length; i++) {
                //the first primary key field is valid.
                if (!primaryKeyField && this.fields[i].isPrimaryKey)
                    primaryKeyField = this.fields[i];
                defs.push(this.fields[i].definition);
            }
            if (primaryKeyField) {
                defs.push("Primary Key ('" + primaryKeyField.name + "')");
            }
            builder.push(defs.join(', '));
            builder.push(');');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFTable.prototype, "php", {
        get: function () {
            var builder = [];
            builder.push('\tclass ' + this.name + '{\n');
            for (var i = 0; i < this.fields.length; i++) {
                builder.push(this.fields[i].php);
            }
            builder.push('\t}\n');
            return builder.join('');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFTable.prototype, "dts", {
        get: function () {
            return '';
        },
        enumerable: true,
        configurable: true
    });
    CFTable.ptnTable = /(^|\n)\s*(export\s+|)class\s+(\w+)\s*\{/g;
    return CFTable;
}());
var FieldModel = (function () {
    function FieldModel() {
    }
    return FieldModel;
}());
var FieldModels = [
    {
        name: 'VarChar',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*string\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(VarChar)\s*\(\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Decimal',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; f.length = Number(m.groups[7]); f.scale = Number(m.groups[8]); },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Decimal)\s*\(\s*(\d+)\s*\,\s*(\d+)\s*\)\s*;/g
    },
    {
        name: 'Int',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Int)\s*\(\s*\)\s*;/g
    },
    {
        name: 'BigInt',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: true, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(BigInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'TinyInt',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(TinyInt)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Bool',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: false, canDefaultNumber: true, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Bool)\s*\(\s*\)\s*;/g
    },
    {
        name: 'Text',
        setFeild: function (m, f) { f.model = f.model; f.name = m.groups[3]; f.attributes = m.groups[4]; f.fieldType = m.groups[6]; },
        canAutoIncrement: false, canDefaultString: true, canDefaultNumber: false, pattern: /(^|\n)\s*(|public\s+)(\w+)\s*\:\s*number\s*=\s*cf\s*\.((?:\s*\w+\s*\((\s*|\s*[\d\.]+\s*|\s*'[\w\W]*'\s*|\s*"[\w\W]*"\s*)\)\s*\.)*)\s*(Text)\s*\(\s*\)\s*;/g
    }
];
var CFField = (function () {
    function CFField(value) {
        this.code = value;
    }
    Object.defineProperty(CFField.prototype, "definition", {
        get: function () {
            //console.log('Name: ' + this.Name);
            //console.log(this.FieldType);
            switch (this.fieldType) {
                case 'VarChar':
                    //console.log('case: VarChar');
                    return "'" + this.name + "'"
                        + ' VARCHAR(' + this.length + ')'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue : '\'');
                case 'Int':
                    return "'" + this.name + "'"
                        + ' Int '
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.isAutoIncrement) ? ' AUTO_INCREMENT ' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Decimal':
                    return "'" + this.name + "'"
                        + ' Deciaml(' + this.length + ',' + this.scale + ')'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'TinyInt':
                    return "'" + this.name + "'"
                        + ' TinyInt'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'BigInt':
                    return "'" + this.name + "'"
                        + ' BigInt'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Bool':
                    return "'" + this.name + "'"
                        + ' TinyInt(1)'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? ' Default ' + this.defaultValue : '');
                case 'Text':
                    return "'" + this.name + "'"
                        + ' Text'
                        + ((this.isPrimaryKey || this.isNotNull) ? ' Not Null' : '')
                        + ((this.hasDefaultValue) ? 'Default \'' + this.defaultValue : '\'');
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CFField.prototype, "php", {
        get: function () {
            return '\t\tpublic $' + this.name + ';\n';
        },
        enumerable: true,
        configurable: true
    });
    CFField.ptnPrimaryKey = /PrimaryKey\s*\(\s*\)/g;
    CFField.ptnNotNull = /NotNull\s*\(\s*\)/g;
    CFField.ptnAutoIncrement = /AutoIncrement\s*\(\s*\)/g;
    CFField.ptnDefaultString = /DefaultString\s*\(\s*(('|")[^']+('|"))\s*\)/g;
    CFField.ptnDefaultNumber = /DefaultNumber\s*\(\s*((\-|)[\d\.]+)\s*\)/g;
    return CFField;
}());
//# sourceMappingURL=cf.js.map