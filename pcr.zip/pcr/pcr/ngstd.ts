﻿module ngstd {
    var debugging: boolean = false;

    export interface INamed {
        TypeName: string;
        clone: (value: any) => any;
    }
    /**
     * the base class for types that can be used for model, where name of the type is important for selecting the template.
     */
    export class NamedObject implements INamed {
        get TypeName(): string {
            var funcNameRegex = /function (.{1,})\(/;
            var results = (funcNameRegex).exec((this).constructor.toString());
            return (results && results.length > 1) ? results[1] : "";
        };
        clone(value: any) {
            for (var attr in value) {
                //console.log(this.TypeName + ".hasOwnProperty" + attr + " :" + this.hasOwnProperty(attr));
                if (attr != "TypeName" && value.hasOwnProperty(attr)) this[attr] = value[attr];
            }
        }
    }
    /**
     * This function deserializes json object by the TypeName property. Your TypeName must contains the module name and class name for eval() call;
     * @param json
     */
    export function TypedJSON(json: any) {
        var copy;
        // Handle the 3 simple types, and null or undefined
        if (null == json || "object" != typeof json) return json;

        // Handle Date
        if (json instanceof Date) {
            copy = new Date();
            copy.setTime(json.getTime());
            return copy;
        }

        // Handle Array
        if (json instanceof Array) {
            copy = [];
            for (var i = 0, len = json.length; i < len; i++) {
                copy[i] = TypedJSON(json[i]);
            }
            return copy;
        }

        // Handle Object
        if (json instanceof Object) {
            var TypeName = "TypeName";
            var name: string;
            if (json.hasOwnProperty(TypeName)) {

                //to use eval to create new class;
                name = json[TypeName];
                copy = eval("new " + name + "()");
                //console.log(copy);
            }
            else {
                copy = {};
            }

            for (var attr in json) {
                if (attr != "TypeName" && json.hasOwnProperty(attr)) copy[attr] = TypedJSON(json[attr]);
            }
            return copy;
        }
    }
    export function SerializeJSON(object: any): string {
        //console.log('Serizlizing: ' + object);
        if (typeof object === 'boolean') return JSON.stringify(object);
        if (object instanceof Date) return JSON.stringify(object);
        if (typeof object === 'string') return JSON.stringify(object);
        if (typeof object === 'number') return JSON.stringify(object);
        if (object instanceof RegExp) return JSON.stringify(object);
        //Handle null
        if (!object) return 'null';

        //Handle Array
        if (object instanceof Array) {
            var codes: string[] = [];
            for (var i: number = 0; i < object.length; i++) {
                codes.push(SerializeJSON(object[i]));
            }
            return '[' + codes.join(',') + ']';
        }

        if (object instanceof Object) {
            var codes: string[] = [];
            //console.log(object instanceof ngstd.NamedObject);
            if (object instanceof ngstd.NamedObject) {
                codes.push('"TypeName": "' + object.TypeName + '"');
            }
            for (var attr in object) {
                //console.log('Attribute: ' + attr + '; OwnProperty: ' + object.hasOwnProperty(attr));
                if (object.hasOwnProperty(attr)) {
                    //console.log('"' + attr + '":' + SerializeJSON(object[attr]));
                    //console.log(object[attr]);
                    codes.push('"' + attr + '":' + SerializeJSON(object[attr]));
                }
                //else {
                //    if (attr = 'TypeName') {
                //        codes.push('"TypeName": "' + object.TypeName + '"');
                //    }
                //}
            }
            return '{' + codes.join(',') + '}';
        }

    }
    /**
     * An implementation of Angular Module. A few important setting features are provided as standard functions.
     */
    export class AngularModule {
        app: ng.IModule;
        constructor(name: string, modules: Array<string>) {
            if (!modules) modules = [];
            this.app = angular.module(name, modules);
        }
        addController(name: string, controller: Function) {
            this.app.controller(name, controller);
        }
        /**
         * Add a directive to the Angular Module;
         * @param name is the name of the directive
         * @param factory is the factory function such as ()=>new Directive(). Directive name won't work.
         */
        addDirective(name: string, factory: ng.IDirectiveFactory) {
            this.app.directive(name, factory);
        }
        addFactory(name: string, factory: Function) {
            this.app.factory(name, factory);
        }
        addService(name: string, service: Function) {
            this.app.service(name, service);
        }
        /**
         * Provide access to the ng.IModule;
         */
        get Base(): ng.IModule {
            return this.app;
        }
        
        /**
         * enables html5 mode for using base<path> and location service;
         */
        public LocationHtml5Mode = () => {
            this.app.config(
                ['$locationProvider',
                    ($locationProvider: ng.ILocationProvider) => {
                        $locationProvider.html5Mode(true);
                    }
                ]
            );
        };
        /**
         * Include Content Directive in this module;
         */
        public includeContentDirective = () => {
            this.addDirective('content', () => new ContentDirective());
        };
        /**
         * Include Sheet Directive in this module;
         */
        public includeSheetDirective = () => {
            this.addDirective('sheet', () => new SheetDirective());
        }
        /**
         * Include Image Directive in this module;
         */
        public includePictureDirective = () => {
            this.addDirective('picture', () => new PictureDirective());
        }

        public includeOpenFileDirective = () => {
            this.addDirective('filebutton', () => new OpenFileDirective());
        }

        public includeMenuGroupDirective = () => {
            this.addDirective('menuGroup', () => new MenuGroupDirective());
        }
        public includeImageSlideDirective = () => {
            this.addDirective('imageslide', () => new ImageSlideDirective());
        }
    }
    /**
     * 
     */
    export class AppController {
        /**
         * Template Selector by Type, this is a default selector
         */
        public TemplateTypeSelector = (data: any, templates: DataTemplate[]) => {
            var nType: ngstd.NamedObject;
            var name: string;
            if (data) {
                if (data instanceof Array) {
                    if (data.length) if (data.length > 0) {
                        nType = data[0];
                        name = nType.TypeName + '[]';
                    } else {
                        name = '';
                    }
                }
                else {
                    nType = data;
                    name = nType.TypeName;
                }
            }
            else {
                name = '';
            }
            //var resolver = new research.metadata.NameResolver();
            //console.log(resolver.getFullClassNameFromInstance(data, window));
            if (debugging) console.log(name); //debugging swtich
            var result: string = '';
            templates.forEach((value: DataTemplate, index: number, array: DataTemplate[]) => {
                if (value.type == name) {
                    result = value.template;
                    return;
                }
            });
            return result;
        };
        /**
         * Template Selector. Always selector the first template.
         */
        public TemplateFirstSelector = (data: any, templates: DataTemplate[]) => {
            if (templates) if (templates.length > 0) {
                return templates[0].template;
            }
            else {
                return '';
            }
        };
    }
    export class DirectiveRestrict {
        static E: string = 'E';
        static A: string = 'A';
        static AE: string = 'AE';
        static C: string = 'C';
    }
    export class BindingRestrict {
        static Both: string = '=';
        static In: string = '@';
        static Out: string = '&';
        static OptionalBoth: string = '=?';
    }
    export class AngularDirective<Scope extends ng.IScope> implements ng.IDirective {
        public restrict: string;
        public template: string;
        public templateUrl: string;
        public scope: Scope = <Scope>{};
        public controller: Function;
        public link: Function;
        constructor() {
            return this;
        }
        public controllerAs: string;
    }

    /**
     * Directive Scope for Content control.
     */
    export interface ContentDirectiveScope extends ng.IScope {
        data: string;
        view: string;
        model: string;
        selector: string;
    }
    /**
     * Controller Scope for Content control.
     */
    export interface ContentScope extends ng.IScope {
        data: any;
        view: string;
        model: any;
        selector: (data: any, templates: DataTemplate[]) => string;
    }
    /**
     * DataTemplate definition for Conent control.
     */
    export class DataTemplate {
        key: string;
        path: string;
        type: string;
        url: string;
        template: string;
    }
    /**
     * Content control controller. It accepts template elements to generate views for data. 
     * It will invoke the selector to evaluate what view to use.
     * We suggest building a TabControl based on Content control.
     * Content control use $compile method to build element within subscope. subscope will be destroyed on the removal of corresponding element.
     */
    export class ContentDirectiveController {
        static $inject = ['$compile', '$element', '$http', '$scope'];
        private childscope: ng.IScope;
        private templates: DataTemplate[] = [];
        constructor(public $compile: ng.ICompileService, public $element: ng.IRootElementService, public $http: ng.IHttpService, public $scope: ContentScope) {
            //this.compiled = this.$compile("<test></test>")(this.$scope);
            //this.$element.append(this.compiled);
            //console.log(this.compiled);

            //this section will collect each of the view template from the inner of this model and they can be applied to each of the software.
            $element.children('template').each((index: number, elem: Element) => {
                var $elem: JQuery = $(elem);
                var template = new DataTemplate();
                template.key = $elem.attr('key');
                template.path = $elem.attr('path');
                template.type = $elem.attr('type');
                template.url = $elem.attr('url');
                if (template.url) {
                    //the embedded template is used for loading process;
                    template.template = $elem.html();
                    $http.get(template.url)
                        .success((data: string) => {
                            template.template = data;
                            //we must check if the return value can affect the view of the content control.
                            if (this.$scope.selector) if ($scope.view != this.$scope.selector($scope.data, this.templates)) {
                                //if view is affected, view must be updated.
                                $scope.view = this.$scope.selector($scope.data, this.templates);
                            }
                        });
                }
                else {
                    template.template = $elem.html();
                }
                this.templates.push(template);
            });
            $element.children().remove();
            this.$scope.$watch(() => this.$scope.data, (newValue: any, oldValue: any) => {
                if (this.$scope.selector) {
                    var template: string = this.$scope.selector(newValue, this.templates);
                    if (template) this.$scope.view = template;
                }
            })
            //this is the way to set up a watch.
            this.$scope.$watch(() => this.$scope.view, (newValue: string, oldValue: string) => {
                //distroy all child elements in the element.
                if (this.childscope) {
                    this.childscope.$destroy();//destroy the child scope
                    this.$element.children().remove();//remove each of the child elments
                }
                //create a new child scope.
                this.childscope = this.$scope.$new();
                //append the complied element
                this.$element.append(this.$compile(newValue)(this.childscope));
            });
        }
    }

    /**
     * Control directive.
     */
    export class ContentDirective extends ngstd.AngularDirective<ContentDirectiveScope>{
        constructor() {
            super();
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '';
            this.scope.data = ngstd.BindingRestrict.Both;
            this.scope.view = ngstd.BindingRestrict.OptionalBoth;
            this.scope.model = ngstd.BindingRestrict.OptionalBoth;
            this.scope.selector = ngstd.BindingRestrict.OptionalBoth;
            this.controller = ContentDirectiveController;
        }
    }

    export class MenuGroupController {
        static $inject = ['$element', '$scope'];
        public element: JQuery;
        public view: JQuery;
        public title: JQuery;
        public parent: JQuery;
        public subScope: ng.IScope;
        constructor(public $element: JQuery, public $scope: ng.IScope) {
            //use $scope to watch size change and work out height for view panel;
            this.element = $element;
            this.parent = $element.parent();
            this.view = $element.children('.view');
            this.title = $element.children('.title');
            $scope.$watch(() => this.parent.height(), (newValue: number, oldValue: number) => {
                this.view.height(this.element.innerHeight() - this.title.outerHeight() - 2);
            });
        }
    }
    export class MenuGroupAlignmentColumn {
        public width: number = 0;
        public height: number = 0;
        public currentHeight: number = 0;
        public alignElement = (elem: Element): boolean => {
            console.log(elem);
            console.log('clientSize: ' + elem.clientWidth + ', ' + elem.clientHeight);
            if (this.currentHeight == 0) {
                //it must fit in even it is bigger than the view;
                this.currentHeight = elem.clientHeight;
                this.width = Math.max(elem.clientWidth, this.width);
                return true;
            } else {
                //it won't fit in if there is already something in the column;
                if (this.currentHeight + elem.clientHeight > this.height) {
                    return false;
                }
                else {
                    this.currentHeight += elem.clientHeight;
                    this.width = Math.max(elem.clientWidth, this.width);
                    return true;
                }
            }
        };
    }
    /**
     * This directive shall be used to automatically adjust tab group view panel height;
     */
    export class MenuGroupDirective extends AngularDirective<ng.IScope>{
        constructor() {
            super();
            this.restrict = DirectiveRestrict.C;
            this.controller = MenuGroupController;
        }
    }


    //ImageSet Classes
    export class ImageSet extends ngstd.NamedObject {
        interval: number;
        width: string;
        height: string;
        images: string[];
    }

    //Table classes:
    export class Table extends ngstd.NamedObject {
        title: string;
        style: string;
        width: string;
        header: TableHeader;
        rows: TableRow[];
    }
    export class TableHeader extends ngstd.NamedObject {
        style: string;
        cells: TableHeadCell[];
    }
    export class TableHeadCell extends ngstd.NamedObject {
        style: string;
        value: string;
    }
    export class TableRow extends ngstd.NamedObject {
        style: string;
        cells: string[];
    }
    export interface SheetDirectiveScope extends ng.IScope {
        data: string;
    }
    //export interface SheetScope extends ng.IScope {
    //    data: ngstd.Table;
    //}
    //export class SheetDirectiveController {
    //    static $inject = ['$element', '$scope'];
    //    constructor(public $element: JQuery, public $scope: SheetScope) {
    //        $scope.controller = this;
    //    }
    //}
    export class SheetDirective extends ngstd.AngularDirective<SheetDirectiveScope> {
        constructor() {
            super();
            this.restrict = ngstd.DirectiveRestrict.E;
            this.templateUrl = 'table.html';
            //'<table>' +
            //'<tr ng-repeat="row in ctrl.rows">' +
            //'<td ng-repeat="cell in row.cells">' +
            //'</td>' +
            //'</tr>' +
            //'</table>';
            this.scope.data = ngstd.BindingRestrict.Both;
            //this.controller = SheetDirectiveController;
            //this.controllerAs = 'ctrl';
        }
    }

    export class PictureDirectiveController {
        static $inject = ["$http", "$scope", "$interval"];
        private scope: PictureScope;
        private interval: ng.IIntervalService;
        private invervalCall: ng.IPromise<any>;
        constructor(public $http: ng.IHttpService, public $scope: PictureScope, public $interval: ng.IIntervalService) {
            this.scope = $scope;
            this.interval = $interval;
            //watch for changes of data;
            $scope.$watch(() => $scope.data, (newValue: string[], oldValue: string[]) => {
                this.start();
            });
            $scope.$watch(() => $scope.interval, (newValue: number, oldValue: number) => {
                this.start();
            });
            $scope.$on('$destroy', () => {
                console.log('picture interval destroyed!');
                if (this.invervalCall) {
                    this.interval.cancel(this.invervalCall);
                    this.invervalCall = null;
                }
            });
        }
        private start = () => {
            if (this.invervalCall) {
                this.interval.cancel(this.invervalCall);
                this.invervalCall = null;
            }
            this.index = 0;
            if (this.scope.data) if (this.scope.data.length > this.index) {
                this.scope.link = this.scope.data[this.index];
                this.index += 1;
                if (this.scope.data.length <= this.index) this.index = 0;
            }
            this.invervalCall = this.interval(() => { this.next(); }, this.scope.interval);
        }
        private count: number = 0;
        private index: number = 0;
        private next = () => {
            this.count += 1;
            if (this.scope.data) if (this.scope.data.length > this.index) {
                this.scope.link = this.scope.data[this.index];
                this.index += 1;
                if (this.scope.data.length <= this.index) this.index = 0;
            }
        }
    }
    export interface PictureDirectiveScope extends ng.IScope {
        data: string;
        width: string;
        height: string;
        interval: string;
    }
    export interface PictureScope extends ng.IScope {
        data: string[];
        link: string;
        width: string;
        height: string;
        interval: number;
    }
    export class PictureDirective extends ngstd.AngularDirective<PictureDirectiveScope>{
        constructor() {
            super();
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '<img ng-src="{{link}}" width="{{width}}" height="{{height}}"/>';
            this.scope.data = ngstd.BindingRestrict.Both;
            this.scope.width = ngstd.BindingRestrict.In;
            this.scope.height = ngstd.BindingRestrict.In;
            this.scope.interval = ngstd.BindingRestrict.In;
            this.controller = PictureDirectiveController;
        }
    }

    export class OpenFileController {
        $inject = ["$element", "$scope"];
        public files: FileList;
        constructor($element: JQuery, $scope: OpenFileScope) {
            var host = $element.children("div");
            var div = <HTMLDivElement>($element.children("div").children("div")[0]);
            var input: JQuery = $element.children("div").children("input");
            var file = <HTMLInputElement>(input[0]);
            //file.clientWidth = div.clientWidth + 100;
            input.width(div.clientWidth + 100);
            $scope.$watch(() => div.clientWidth, (newValue: number, oldValue: number) => { //a good method to watch for/detect element size change;
                //file.clientHeight = div.clientWidth + 100;
                host.width(div.clientWidth);
                input.width(div.clientWidth + 100);
            });
            file.onchange = () => {
                $scope.files = file.files;
                $scope.$apply();
                if ($scope.changed) {
                    $scope.changed(file.files);
                }
                else {
                    console.log('Directive "filebutton" requres "changed" function for process your file.');
                }
            };
        }
    }

    export interface OpenFileScope extends ng.IScope {
        name: string;
        files: FileList;
        changed: (value: FileList) => void;
        accept: string;
    }

    export interface OpenFileDirectiveScope extends ng.IScope {
        name: string;
        files: string;
        changed: string;
        accept: string;
    }

    export class OpenFileDirective extends ngstd.AngularDirective<OpenFileDirectiveScope>{
        constructor() {
            super();
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '<div class="fileinputs btn btn-default btn-xs menu"><div>{{name}}</div><input type= "file" accept="{{accept}}" class="file"/></div>'; //<div class="fakefile">Open File</div>
            this.scope.name = ngstd.BindingRestrict.Both;
            this.scope.files = ngstd.BindingRestrict.OptionalBoth;
            this.scope.changed = ngstd.BindingRestrict.Both;
            this.scope.accept = ngstd.BindingRestrict.Both;
            this.controller = OpenFileController;
        }
    }

    //menu 
    export class TabControl extends NamedObject {
        public items: TabItem[] = [];
        public addTabItem = (item: TabItem) => {
            this.items.push(item);
            item.parent = this;
            return item;
        }
        public selectedContent: any;
        public selectTab(item: TabItem) {
            this.items.forEach((value: TabItem, index: number, array: TabItem[]) => {
                if (value === item) {
                    value.style = "'tab-pane active'";
                    this.selectedContent = item.content;
                }
                else {
                    value.style = "";
                }
            });
        }
    }
    export class TabItem extends NamedObject {
        public name: string;
        public style: string;
        public parent: TabControl;
        public select() {
            if (this.parent) this.parent.selectTab(this);
        };
        public content: any;//this is the content object for the tab menu;
    }
    export class TabContent extends NamedObject {
        public groups: MenuGroup[] = [];
        public addGroup = (item: MenuGroup) => {
            this.groups.push(item);
        }
    }
    export class MenuGroup extends NamedObject {
        public name: string;
        public width: string = 'auto';
        public items: any[] = [];
        public addItem = (item: any) => {
            this.items.push(item);
        }
    }
    export class MenuItem extends NamedObject {
        public name: string;
        public click: () => void;
    }
    export class FileMenuItem extends NamedObject {
        public name: string;
        public accept: string;
        public click: (files: FileList) => void;
    }


    export class ImageSlideController {
        $inject = ['$element', '$scope', '$interval'];
        constructor(public $element: JQuery, public $scope: ImageSlideScope, public $interval: ng.IIntervalService) {
            var host = $element.children('div');
            var divs = host.children('div');
            var div1 = jQuery(divs[0]);
            var div2 = jQuery(divs[1]);

            var countDown: number = 0;
            var index: number = 0;
            var mode: boolean= true;

            var getNextImage: ()=>string = () => {
                index += 1;
                if (index >= $scope.images.length) index = 0;
                if ($scope.images.length == 0) return '';
                return $scope.images[index];
            }

            if ($scope.images.length > 0) {
                $scope.img1 = $scope.images[0];
                $scope.img2 = getNextImage();
            }
            //var watch = $scope.$watch(() => host.width(), (newValue: number, oldValue: number) => {
            //    //div1.width(newValue+'px');
            //    div2.width(newValue+'px');
            //});
            var int = $interval(() => {
                countDown += 1;
                var interval: number = Number($scope.interval);
                var transition: number = Number($scope.transition);
                if (countDown >= (interval + transition)) {
                    console.log('greater');
                    countDown = 0;
                    mode = !mode;
                    if (mode) {
                        $scope.img2 = getNextImage();
                    }
                    else {
                        $scope.img1 = getNextImage();
                    }
                }
                //if (countDown == 0) {
                //    console.log(div1);
                //    console.log(div2);
                //    if (mode) {
                //        //console.log('true div1 set to 0%');
                //        div1.css('left', '0%');
                //        div2.css('left', '101%');
                //        $scope.img2 = getNextImage();
                //    }
                //    else {
                //        //console.log('false div2 set to 0%');
                //        div2.css('left', '0%');
                //        div1.css('left', '101%');
                //        $scope.img1 = getNextImage();
                //    }
                //}
                if (countDown > interval) {
                    var value = Math.round(-((countDown - interval) / transition) * 100);
                    if (mode) {
                        //console.log('true div1: ' + value);
                        //console.log('true div2: ' + (100+value));
                        //div1.css('left', value.toString() + '%');
                        //div2.css('left', (100 + value).toString() + '%');

                        div1.fadeOut(transition * 25);
                        div2.fadeIn(transition * 25);
                    }
                    else {
                        //console.log('false div1: ' + (100 + value));
                        //console.log('false div2: ' + value);
                        //div2.css('left', value.toString() + '%');
                        //div1.css('left', (100 + value).toString() + '%');
                        div2.fadeOut(transition * 25);
                        div1.fadeIn(transition * 25);
                    }
                }

                //console.log('div1 left:'+ div1.css('left'));
                //console.log('div2 left:'+div2.css('left'));
                //console.log(interval + transition);
                //console.log(countDown);
            }, 50);
            $scope.$on('$destroy', (event) => {
                if (angular.isDefined(int))
                    $interval.cancel(int);
            });
        }
    }
    export interface ImageSlideScope extends ng.IScope {
        images: string[];
        interval: string;
        transition: string;
        img1: string;
        img2: string;
    }
    export interface ImageSlideDirectiveScope extends ng.IScope {
        images: string;
        interval: string;
        transition: string;
    }
    export class ImageSlideDirective extends ngstd.AngularDirective<ImageSlideDirectiveScope>{
        constructor() {
            super();
            this.restrict = ngstd.DirectiveRestrict.E;
            this.templateUrl = 'ImageSlide.html';
            this.scope.images = ngstd.BindingRestrict.OptionalBoth;
            this.scope.interval = ngstd.BindingRestrict.In;
            this.scope.transition = ngstd.BindingRestrict.In;
            this.controller = ImageSlideController;
        }
    }
}

/**
 * PHPPostObj is used to post command to the php service; It is used by the rpc.html and php.html;
 */
class PHPPostObj {
    public method: string;
    public value: FileBuiler[] = [];
}
/**
 * FileBuilder is the interface to make php service to create/write specific file on the server side; It is used by rpc.html and php.html;
 */
class FileBuiler {
    public filename: string;
    public content: string;
}
/**
 * CompilerInclude defines patterns required by RPC and PHP compiler;
 */
class CompilerPattern {
    static ptnRPCInclude = /\/\/rpc(\s+include\s+(('[\w\d]+'\s*)*)|)\s*/ig;
    static ptnIncludeFile = /'([\w\-]+)'/ig;
    static ptnPHPInclude = /\/\/php(\s+include\s+(('[\w\d]+'\s*)*)|)\s*/ig;
    static ptnService = /(^|\n)\s*(export\s+|)(interface|class)\s+(\w+)\s*\{/g;
}
/**
 * The standard pattern libraries for analyzing typescript entities;
 */
class StdPatterns {
    static ptnModule = /(^|\n)\s*module\s+(\w+)\s*\{/g;
    static ptnClass = /(^|\n)\s*(export\s+|)class\s+(\w+)\s*\{/g;
    static ptnInterface = /(^|\n)\s*(export\s+|)interface\s+(\w+)\s*\{/g;
    static ptnInterfaceMethod = /([\w][\w\d\.]*)\s*\(((\s*([\w][\w\d\.]*)\s*\:\s*([\w][\w\d\.]*)(|\s*\[\s*\])\s*(|\,))*)\)\s*\:\s*(([\w][\w\d\.]*)(\s*\[\s*\]|))/g;
    static ptnParameter = /\s*([\w][\w\d\.]*)\s*\:\s*(([\w][\w\d\.]*)\s*(\[\s*\]|))/g;
}

/**
 * class for registering RPC calls for remote service; you must pass the $http service to this class so as to make RPC calls work;
 */
class RPC {
    static http: ng.IHttpService;
}

function ngInject (...args: ns[]):string[] {
        var services: string[] = [];
        for (var i: number = 0; i < args.length; i++) {
            switch (args[i]) {
                case ns.http:
                    services.push('$http');
                    break;
                case ns.scope:
                    services.push('$scope');
                    break;
            }
        }
        return services;
}

enum ns {
    http,
    scope,
    rootScope
}