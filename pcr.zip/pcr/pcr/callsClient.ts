module loginClient {
  export class login {
      public static login (method:string, 
          _SuccessCallback: ng.IHttpPromiseCallback<boolean>, 
          _ErrorCallback?: ng.IHttpPromiseCallback<boolean>) {
          var _RemoteProcedureCallObject: rpc = {
                  service: 'login', method: 'login', parameters: [method]
              }
          RPC.http.post('login.php', _RemoteProcedureCallObject)
              .success(_SuccessCallback)
              .error(_ErrorCallback);
      }
  }

}
