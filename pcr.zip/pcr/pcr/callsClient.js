var loginClient;
(function (loginClient) {
    var login = (function () {
        function login() {
        }
        login.login = function (method, _SuccessCallback, _ErrorCallback) {
            var _RemoteProcedureCallObject = {
                service: 'login', method: 'login', parameters: [method]
            };
            RPC.http.post('login.php', _RemoteProcedureCallObject)
                .success(_SuccessCallback)
                .error(_ErrorCallback);
        };
        return login;
    }());
    loginClient.login = login;
})(loginClient || (loginClient = {}));
//# sourceMappingURL=callsClient.js.map