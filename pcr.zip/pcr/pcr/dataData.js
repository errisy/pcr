var MarketSpecialData;
(function (MarketSpecialData) {
    var Company = (function () {
        function Company() {
        }
        return Company;
    }());
    MarketSpecialData.Company = Company;
    var TableCreation = (function () {
        function TableCreation() {
            this.MarketSpecial_Company = "Create Table MarketSpecial.Company(id Int  Not Null AUTO_INCREMENT , name VARCHAR(80), address VARCHAR(255), Primary Key (id));";
        }
        return TableCreation;
    }());
    MarketSpecialData.TableCreation = TableCreation;
})(MarketSpecialData || (MarketSpecialData = {}));
//# sourceMappingURL=dataData.js.map