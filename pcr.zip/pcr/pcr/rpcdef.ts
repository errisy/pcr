﻿// to be used by remote procedure calls
class rpc {
    service: string;
    method: string;
    parameters: any[];
}