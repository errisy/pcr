﻿/**
 * PHP Function: decode json string into object
 * @param value
 */
declare function json_decode(value: string): any;
/**
 * PHP Function: encode object into json string
 * @param value
 */
declare function json_encode(value: any): string;
/**
 * 
 * @param value
 */
declare function file_get_contents(value: string): any;
/**
 * PHP Function: send string value to output stream;
 * @param value
 */
declare function echo(value: string): void;
/**
 * PHP Function: convert a string to lower case;
 * @param value
 */
declare function strtolower(value: string): string;
/**
 * convert a string to upper case;
 * @param value
 */
declare function strtoupper(value: string): string;
/**
 * PHP Function: list all files in a directory
 * @param directory
 */
declare function scandir(directory: string): string[];
/**
 * PHP Function: initialize an array; 
 */
declare function array(): any[]; 
/**
 * PHP Function: add a value to the end of an PHP array;
 * @param arr
 * @param value
 */
declare function array_push(arr: any[], value: any);
/**
 * PHP Function: get the size of the array;
 * @param arr
 */
declare function sizeof(arr: any[]): number;
/**
 * PHP Function:
 * @param resultmetadata
 */
declare function mysqli_fetch_field(resultmetadata: MySQLiResultMetadata): MySQLiField;
/**
 * PHP Function: fetch the array from the mysql result;
 * @param result
 */
declare function mysqli_fetch_array(result: MySQLiResult):any[];
/**
 * PHP Function: release the resources held by the mysql result;
 * @param result
 */
declare function mysqli_free_result(result: MySQLiResult): boolean;
/**
 * PHP Function: write value to the output stream;
 * @param value
 */
declare function echo(value: string);
/**
 * PHP Function: write value to the output stream;
 * @param value
 */
declare function print(value: string);
/**
 * PHP Function: write value to the output stream and close the transcation;
 * @param value
 */
declare function die(value: string);
/**
 * PHP Function connect MySQL with mysqli interface; the new mysqli(....) method can cause typescript-php compiler error, so we don't use that;
 * @param server
 * @param username
 * @param password
 * @param database
 */
declare function mysqli_connect(server: string, username: string, password: string, database: string): mysqli;

declare class mysqli {
    public connect_error: string;
    public query(sql: string): MySQLiResult;
    public stmt_init(): mysqli_stmt;
    /**
     * PHP Function: close the MySQLi connection;
     */
    public close(): void;
}

declare class MySQLiField {
    public name: string;
}
declare class MySQLiResult {
    
}


declare class mysqli_stmt {
    /**
     * get result metadata from mysql statement after 'execute'.
     */
    public result_metadata(): MySQLiResultMetadata;
    /**
     * set the query string to the mysql statement;
     * @param sql
     */
    public prepare(sql: string): void;
    /**
     * Bind variables to the ? in the mysql query string;
     * @param types: i for int, d for double, s for string, b for blob;
     * @param args: arguments, the number of arguments must match the number of types; 
     */
    public bind_param(types: string, ...args: any[]);
    /**
     * execute the mysql statment so as to perform the query;
     */
    public execute(): void;
    /**
     * get result from MySql statement after 'execute';
     */
    public get_result(): MySQLiResult; 
    
    public error: string;
}

declare class MySQLiResultMetadata extends MySQLiResult {

}