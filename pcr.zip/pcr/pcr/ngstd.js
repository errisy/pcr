var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var ngstd;
(function (ngstd) {
    var debugging = false;
    /**
     * the base class for types that can be used for model, where name of the type is important for selecting the template.
     */
    var NamedObject = (function () {
        function NamedObject() {
        }
        Object.defineProperty(NamedObject.prototype, "TypeName", {
            get: function () {
                var funcNameRegex = /function (.{1,})\(/;
                var results = (funcNameRegex).exec((this).constructor.toString());
                return (results && results.length > 1) ? results[1] : "";
            },
            enumerable: true,
            configurable: true
        });
        ;
        NamedObject.prototype.clone = function (value) {
            for (var attr in value) {
                //console.log(this.TypeName + ".hasOwnProperty" + attr + " :" + this.hasOwnProperty(attr));
                if (attr != "TypeName" && value.hasOwnProperty(attr))
                    this[attr] = value[attr];
            }
        };
        return NamedObject;
    }());
    ngstd.NamedObject = NamedObject;
    /**
     * This function deserializes json object by the TypeName property. Your TypeName must contains the module name and class name for eval() call;
     * @param json
     */
    function TypedJSON(json) {
        var copy;
        // Handle the 3 simple types, and null or undefined
        if (null == json || "object" != typeof json)
            return json;
        // Handle Date
        if (json instanceof Date) {
            copy = new Date();
            copy.setTime(json.getTime());
            return copy;
        }
        // Handle Array
        if (json instanceof Array) {
            copy = [];
            for (var i = 0, len = json.length; i < len; i++) {
                copy[i] = TypedJSON(json[i]);
            }
            return copy;
        }
        // Handle Object
        if (json instanceof Object) {
            var TypeName = "TypeName";
            var name;
            if (json.hasOwnProperty(TypeName)) {
                //to use eval to create new class;
                name = json[TypeName];
                copy = eval("new " + name + "()");
            }
            else {
                copy = {};
            }
            for (var attr in json) {
                if (attr != "TypeName" && json.hasOwnProperty(attr))
                    copy[attr] = TypedJSON(json[attr]);
            }
            return copy;
        }
    }
    ngstd.TypedJSON = TypedJSON;
    function SerializeJSON(object) {
        //console.log('Serizlizing: ' + object);
        if (typeof object === 'boolean')
            return JSON.stringify(object);
        if (object instanceof Date)
            return JSON.stringify(object);
        if (typeof object === 'string')
            return JSON.stringify(object);
        if (typeof object === 'number')
            return JSON.stringify(object);
        if (object instanceof RegExp)
            return JSON.stringify(object);
        //Handle null
        if (!object)
            return 'null';
        //Handle Array
        if (object instanceof Array) {
            var codes = [];
            for (var i = 0; i < object.length; i++) {
                codes.push(SerializeJSON(object[i]));
            }
            return '[' + codes.join(',') + ']';
        }
        if (object instanceof Object) {
            var codes = [];
            //console.log(object instanceof ngstd.NamedObject);
            if (object instanceof ngstd.NamedObject) {
                codes.push('"TypeName": "' + object.TypeName + '"');
            }
            for (var attr in object) {
                //console.log('Attribute: ' + attr + '; OwnProperty: ' + object.hasOwnProperty(attr));
                if (object.hasOwnProperty(attr)) {
                    //console.log('"' + attr + '":' + SerializeJSON(object[attr]));
                    //console.log(object[attr]);
                    codes.push('"' + attr + '":' + SerializeJSON(object[attr]));
                }
            }
            return '{' + codes.join(',') + '}';
        }
    }
    ngstd.SerializeJSON = SerializeJSON;
    /**
     * An implementation of Angular Module. A few important setting features are provided as standard functions.
     */
    var AngularModule = (function () {
        function AngularModule(name, modules) {
            var _this = this;
            /**
             * enables html5 mode for using base<path> and location service;
             */
            this.LocationHtml5Mode = function () {
                _this.app.config(['$locationProvider',
                    function ($locationProvider) {
                        $locationProvider.html5Mode(true);
                    }
                ]);
            };
            /**
             * Include Content Directive in this module;
             */
            this.includeContentDirective = function () {
                _this.addDirective('content', function () { return new ContentDirective(); });
            };
            /**
             * Include Sheet Directive in this module;
             */
            this.includeSheetDirective = function () {
                _this.addDirective('sheet', function () { return new SheetDirective(); });
            };
            /**
             * Include Image Directive in this module;
             */
            this.includePictureDirective = function () {
                _this.addDirective('picture', function () { return new PictureDirective(); });
            };
            this.includeOpenFileDirective = function () {
                _this.addDirective('filebutton', function () { return new OpenFileDirective(); });
            };
            this.includeMenuGroupDirective = function () {
                _this.addDirective('menuGroup', function () { return new MenuGroupDirective(); });
            };
            this.includeImageSlideDirective = function () {
                _this.addDirective('imageslide', function () { return new ImageSlideDirective(); });
            };
            if (!modules)
                modules = [];
            this.app = angular.module(name, modules);
        }
        AngularModule.prototype.addController = function (name, controller) {
            this.app.controller(name, controller);
        };
        /**
         * Add a directive to the Angular Module;
         * @param name is the name of the directive
         * @param factory is the factory function such as ()=>new Directive(). Directive name won't work.
         */
        AngularModule.prototype.addDirective = function (name, factory) {
            this.app.directive(name, factory);
        };
        AngularModule.prototype.addFactory = function (name, factory) {
            this.app.factory(name, factory);
        };
        AngularModule.prototype.addService = function (name, service) {
            this.app.service(name, service);
        };
        Object.defineProperty(AngularModule.prototype, "Base", {
            /**
             * Provide access to the ng.IModule;
             */
            get: function () {
                return this.app;
            },
            enumerable: true,
            configurable: true
        });
        return AngularModule;
    }());
    ngstd.AngularModule = AngularModule;
    /**
     *
     */
    var AppController = (function () {
        function AppController() {
            /**
             * Template Selector by Type, this is a default selector
             */
            this.TemplateTypeSelector = function (data, templates) {
                var nType;
                var name;
                if (data) {
                    if (data instanceof Array) {
                        if (data.length)
                            if (data.length > 0) {
                                nType = data[0];
                                name = nType.TypeName + '[]';
                            }
                            else {
                                name = '';
                            }
                    }
                    else {
                        nType = data;
                        name = nType.TypeName;
                    }
                }
                else {
                    name = '';
                }
                //var resolver = new research.metadata.NameResolver();
                //console.log(resolver.getFullClassNameFromInstance(data, window));
                if (debugging)
                    console.log(name); //debugging swtich
                var result = '';
                templates.forEach(function (value, index, array) {
                    if (value.type == name) {
                        result = value.template;
                        return;
                    }
                });
                return result;
            };
            /**
             * Template Selector. Always selector the first template.
             */
            this.TemplateFirstSelector = function (data, templates) {
                if (templates)
                    if (templates.length > 0) {
                        return templates[0].template;
                    }
                    else {
                        return '';
                    }
            };
        }
        return AppController;
    }());
    ngstd.AppController = AppController;
    var DirectiveRestrict = (function () {
        function DirectiveRestrict() {
        }
        DirectiveRestrict.E = 'E';
        DirectiveRestrict.A = 'A';
        DirectiveRestrict.AE = 'AE';
        DirectiveRestrict.C = 'C';
        return DirectiveRestrict;
    }());
    ngstd.DirectiveRestrict = DirectiveRestrict;
    var BindingRestrict = (function () {
        function BindingRestrict() {
        }
        BindingRestrict.Both = '=';
        BindingRestrict.In = '@';
        BindingRestrict.Out = '&';
        BindingRestrict.OptionalBoth = '=?';
        return BindingRestrict;
    }());
    ngstd.BindingRestrict = BindingRestrict;
    var AngularDirective = (function () {
        function AngularDirective() {
            this.scope = {};
            return this;
        }
        return AngularDirective;
    }());
    ngstd.AngularDirective = AngularDirective;
    /**
     * DataTemplate definition for Conent control.
     */
    var DataTemplate = (function () {
        function DataTemplate() {
        }
        return DataTemplate;
    }());
    ngstd.DataTemplate = DataTemplate;
    /**
     * Content control controller. It accepts template elements to generate views for data.
     * It will invoke the selector to evaluate what view to use.
     * We suggest building a TabControl based on Content control.
     * Content control use $compile method to build element within subscope. subscope will be destroyed on the removal of corresponding element.
     */
    var ContentDirectiveController = (function () {
        function ContentDirectiveController($compile, $element, $http, $scope) {
            //this.compiled = this.$compile("<test></test>")(this.$scope);
            //this.$element.append(this.compiled);
            //console.log(this.compiled);
            var _this = this;
            this.$compile = $compile;
            this.$element = $element;
            this.$http = $http;
            this.$scope = $scope;
            this.templates = [];
            //this section will collect each of the view template from the inner of this model and they can be applied to each of the software.
            $element.children('template').each(function (index, elem) {
                var $elem = $(elem);
                var template = new DataTemplate();
                template.key = $elem.attr('key');
                template.path = $elem.attr('path');
                template.type = $elem.attr('type');
                template.url = $elem.attr('url');
                if (template.url) {
                    //the embedded template is used for loading process;
                    template.template = $elem.html();
                    $http.get(template.url)
                        .success(function (data) {
                        template.template = data;
                        //we must check if the return value can affect the view of the content control.
                        if (_this.$scope.selector)
                            if ($scope.view != _this.$scope.selector($scope.data, _this.templates)) {
                                //if view is affected, view must be updated.
                                $scope.view = _this.$scope.selector($scope.data, _this.templates);
                            }
                    });
                }
                else {
                    template.template = $elem.html();
                }
                _this.templates.push(template);
            });
            $element.children().remove();
            this.$scope.$watch(function () { return _this.$scope.data; }, function (newValue, oldValue) {
                if (_this.$scope.selector) {
                    var template = _this.$scope.selector(newValue, _this.templates);
                    if (template)
                        _this.$scope.view = template;
                }
            });
            //this is the way to set up a watch.
            this.$scope.$watch(function () { return _this.$scope.view; }, function (newValue, oldValue) {
                //distroy all child elements in the element.
                if (_this.childscope) {
                    _this.childscope.$destroy(); //destroy the child scope
                    _this.$element.children().remove(); //remove each of the child elments
                }
                //create a new child scope.
                _this.childscope = _this.$scope.$new();
                //append the complied element
                _this.$element.append(_this.$compile(newValue)(_this.childscope));
            });
        }
        ContentDirectiveController.$inject = ['$compile', '$element', '$http', '$scope'];
        return ContentDirectiveController;
    }());
    ngstd.ContentDirectiveController = ContentDirectiveController;
    /**
     * Control directive.
     */
    var ContentDirective = (function (_super) {
        __extends(ContentDirective, _super);
        function ContentDirective() {
            _super.call(this);
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '';
            this.scope.data = ngstd.BindingRestrict.Both;
            this.scope.view = ngstd.BindingRestrict.OptionalBoth;
            this.scope.model = ngstd.BindingRestrict.OptionalBoth;
            this.scope.selector = ngstd.BindingRestrict.OptionalBoth;
            this.controller = ContentDirectiveController;
        }
        return ContentDirective;
    }(ngstd.AngularDirective));
    ngstd.ContentDirective = ContentDirective;
    var MenuGroupController = (function () {
        function MenuGroupController($element, $scope) {
            var _this = this;
            this.$element = $element;
            this.$scope = $scope;
            //use $scope to watch size change and work out height for view panel;
            this.element = $element;
            this.parent = $element.parent();
            this.view = $element.children('.view');
            this.title = $element.children('.title');
            $scope.$watch(function () { return _this.parent.height(); }, function (newValue, oldValue) {
                _this.view.height(_this.element.innerHeight() - _this.title.outerHeight() - 2);
            });
        }
        MenuGroupController.$inject = ['$element', '$scope'];
        return MenuGroupController;
    }());
    ngstd.MenuGroupController = MenuGroupController;
    var MenuGroupAlignmentColumn = (function () {
        function MenuGroupAlignmentColumn() {
            var _this = this;
            this.width = 0;
            this.height = 0;
            this.currentHeight = 0;
            this.alignElement = function (elem) {
                console.log(elem);
                console.log('clientSize: ' + elem.clientWidth + ', ' + elem.clientHeight);
                if (_this.currentHeight == 0) {
                    //it must fit in even it is bigger than the view;
                    _this.currentHeight = elem.clientHeight;
                    _this.width = Math.max(elem.clientWidth, _this.width);
                    return true;
                }
                else {
                    //it won't fit in if there is already something in the column;
                    if (_this.currentHeight + elem.clientHeight > _this.height) {
                        return false;
                    }
                    else {
                        _this.currentHeight += elem.clientHeight;
                        _this.width = Math.max(elem.clientWidth, _this.width);
                        return true;
                    }
                }
            };
        }
        return MenuGroupAlignmentColumn;
    }());
    ngstd.MenuGroupAlignmentColumn = MenuGroupAlignmentColumn;
    /**
     * This directive shall be used to automatically adjust tab group view panel height;
     */
    var MenuGroupDirective = (function (_super) {
        __extends(MenuGroupDirective, _super);
        function MenuGroupDirective() {
            _super.call(this);
            this.restrict = DirectiveRestrict.C;
            this.controller = MenuGroupController;
        }
        return MenuGroupDirective;
    }(AngularDirective));
    ngstd.MenuGroupDirective = MenuGroupDirective;
    //ImageSet Classes
    var ImageSet = (function (_super) {
        __extends(ImageSet, _super);
        function ImageSet() {
            _super.apply(this, arguments);
        }
        return ImageSet;
    }(ngstd.NamedObject));
    ngstd.ImageSet = ImageSet;
    //Table classes:
    var Table = (function (_super) {
        __extends(Table, _super);
        function Table() {
            _super.apply(this, arguments);
        }
        return Table;
    }(ngstd.NamedObject));
    ngstd.Table = Table;
    var TableHeader = (function (_super) {
        __extends(TableHeader, _super);
        function TableHeader() {
            _super.apply(this, arguments);
        }
        return TableHeader;
    }(ngstd.NamedObject));
    ngstd.TableHeader = TableHeader;
    var TableHeadCell = (function (_super) {
        __extends(TableHeadCell, _super);
        function TableHeadCell() {
            _super.apply(this, arguments);
        }
        return TableHeadCell;
    }(ngstd.NamedObject));
    ngstd.TableHeadCell = TableHeadCell;
    var TableRow = (function (_super) {
        __extends(TableRow, _super);
        function TableRow() {
            _super.apply(this, arguments);
        }
        return TableRow;
    }(ngstd.NamedObject));
    ngstd.TableRow = TableRow;
    //export interface SheetScope extends ng.IScope {
    //    data: ngstd.Table;
    //}
    //export class SheetDirectiveController {
    //    static $inject = ['$element', '$scope'];
    //    constructor(public $element: JQuery, public $scope: SheetScope) {
    //        $scope.controller = this;
    //    }
    //}
    var SheetDirective = (function (_super) {
        __extends(SheetDirective, _super);
        function SheetDirective() {
            _super.call(this);
            this.restrict = ngstd.DirectiveRestrict.E;
            this.templateUrl = 'table.html';
            //'<table>' +
            //'<tr ng-repeat="row in ctrl.rows">' +
            //'<td ng-repeat="cell in row.cells">' +
            //'</td>' +
            //'</tr>' +
            //'</table>';
            this.scope.data = ngstd.BindingRestrict.Both;
            //this.controller = SheetDirectiveController;
            //this.controllerAs = 'ctrl';
        }
        return SheetDirective;
    }(ngstd.AngularDirective));
    ngstd.SheetDirective = SheetDirective;
    var PictureDirectiveController = (function () {
        function PictureDirectiveController($http, $scope, $interval) {
            var _this = this;
            this.$http = $http;
            this.$scope = $scope;
            this.$interval = $interval;
            this.start = function () {
                if (_this.invervalCall) {
                    _this.interval.cancel(_this.invervalCall);
                    _this.invervalCall = null;
                }
                _this.index = 0;
                if (_this.scope.data)
                    if (_this.scope.data.length > _this.index) {
                        _this.scope.link = _this.scope.data[_this.index];
                        _this.index += 1;
                        if (_this.scope.data.length <= _this.index)
                            _this.index = 0;
                    }
                _this.invervalCall = _this.interval(function () { _this.next(); }, _this.scope.interval);
            };
            this.count = 0;
            this.index = 0;
            this.next = function () {
                _this.count += 1;
                if (_this.scope.data)
                    if (_this.scope.data.length > _this.index) {
                        _this.scope.link = _this.scope.data[_this.index];
                        _this.index += 1;
                        if (_this.scope.data.length <= _this.index)
                            _this.index = 0;
                    }
            };
            this.scope = $scope;
            this.interval = $interval;
            //watch for changes of data;
            $scope.$watch(function () { return $scope.data; }, function (newValue, oldValue) {
                _this.start();
            });
            $scope.$watch(function () { return $scope.interval; }, function (newValue, oldValue) {
                _this.start();
            });
            $scope.$on('$destroy', function () {
                console.log('picture interval destroyed!');
                if (_this.invervalCall) {
                    _this.interval.cancel(_this.invervalCall);
                    _this.invervalCall = null;
                }
            });
        }
        PictureDirectiveController.$inject = ["$http", "$scope", "$interval"];
        return PictureDirectiveController;
    }());
    ngstd.PictureDirectiveController = PictureDirectiveController;
    var PictureDirective = (function (_super) {
        __extends(PictureDirective, _super);
        function PictureDirective() {
            _super.call(this);
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '<img ng-src="{{link}}" width="{{width}}" height="{{height}}"/>';
            this.scope.data = ngstd.BindingRestrict.Both;
            this.scope.width = ngstd.BindingRestrict.In;
            this.scope.height = ngstd.BindingRestrict.In;
            this.scope.interval = ngstd.BindingRestrict.In;
            this.controller = PictureDirectiveController;
        }
        return PictureDirective;
    }(ngstd.AngularDirective));
    ngstd.PictureDirective = PictureDirective;
    var OpenFileController = (function () {
        function OpenFileController($element, $scope) {
            this.$inject = ["$element", "$scope"];
            var host = $element.children("div");
            var div = ($element.children("div").children("div")[0]);
            var input = $element.children("div").children("input");
            var file = (input[0]);
            //file.clientWidth = div.clientWidth + 100;
            input.width(div.clientWidth + 100);
            $scope.$watch(function () { return div.clientWidth; }, function (newValue, oldValue) {
                //file.clientHeight = div.clientWidth + 100;
                host.width(div.clientWidth);
                input.width(div.clientWidth + 100);
            });
            file.onchange = function () {
                $scope.files = file.files;
                $scope.$apply();
                if ($scope.changed) {
                    $scope.changed(file.files);
                }
                else {
                    console.log('Directive "filebutton" requres "changed" function for process your file.');
                }
            };
        }
        return OpenFileController;
    }());
    ngstd.OpenFileController = OpenFileController;
    var OpenFileDirective = (function (_super) {
        __extends(OpenFileDirective, _super);
        function OpenFileDirective() {
            _super.call(this);
            this.restrict = ngstd.DirectiveRestrict.E;
            this.template = '<div class="fileinputs btn btn-default btn-xs menu"><div>{{name}}</div><input type= "file" accept="{{accept}}" class="file"/></div>'; //<div class="fakefile">Open File</div>
            this.scope.name = ngstd.BindingRestrict.Both;
            this.scope.files = ngstd.BindingRestrict.OptionalBoth;
            this.scope.changed = ngstd.BindingRestrict.Both;
            this.scope.accept = ngstd.BindingRestrict.Both;
            this.controller = OpenFileController;
        }
        return OpenFileDirective;
    }(ngstd.AngularDirective));
    ngstd.OpenFileDirective = OpenFileDirective;
    //menu 
    var TabControl = (function (_super) {
        __extends(TabControl, _super);
        function TabControl() {
            var _this = this;
            _super.apply(this, arguments);
            this.items = [];
            this.addTabItem = function (item) {
                _this.items.push(item);
                item.parent = _this;
                return item;
            };
        }
        TabControl.prototype.selectTab = function (item) {
            var _this = this;
            this.items.forEach(function (value, index, array) {
                if (value === item) {
                    value.style = "'tab-pane active'";
                    _this.selectedContent = item.content;
                }
                else {
                    value.style = "";
                }
            });
        };
        return TabControl;
    }(NamedObject));
    ngstd.TabControl = TabControl;
    var TabItem = (function (_super) {
        __extends(TabItem, _super);
        function TabItem() {
            _super.apply(this, arguments);
        }
        TabItem.prototype.select = function () {
            if (this.parent)
                this.parent.selectTab(this);
        };
        ;
        return TabItem;
    }(NamedObject));
    ngstd.TabItem = TabItem;
    var TabContent = (function (_super) {
        __extends(TabContent, _super);
        function TabContent() {
            var _this = this;
            _super.apply(this, arguments);
            this.groups = [];
            this.addGroup = function (item) {
                _this.groups.push(item);
            };
        }
        return TabContent;
    }(NamedObject));
    ngstd.TabContent = TabContent;
    var MenuGroup = (function (_super) {
        __extends(MenuGroup, _super);
        function MenuGroup() {
            var _this = this;
            _super.apply(this, arguments);
            this.width = 'auto';
            this.items = [];
            this.addItem = function (item) {
                _this.items.push(item);
            };
        }
        return MenuGroup;
    }(NamedObject));
    ngstd.MenuGroup = MenuGroup;
    var MenuItem = (function (_super) {
        __extends(MenuItem, _super);
        function MenuItem() {
            _super.apply(this, arguments);
        }
        return MenuItem;
    }(NamedObject));
    ngstd.MenuItem = MenuItem;
    var FileMenuItem = (function (_super) {
        __extends(FileMenuItem, _super);
        function FileMenuItem() {
            _super.apply(this, arguments);
        }
        return FileMenuItem;
    }(NamedObject));
    ngstd.FileMenuItem = FileMenuItem;
    var ImageSlideController = (function () {
        function ImageSlideController($element, $scope, $interval) {
            this.$element = $element;
            this.$scope = $scope;
            this.$interval = $interval;
            this.$inject = ['$element', '$scope', '$interval'];
            var host = $element.children('div');
            var divs = host.children('div');
            var div1 = jQuery(divs[0]);
            var div2 = jQuery(divs[1]);
            var countDown = 0;
            var index = 0;
            var mode = true;
            var getNextImage = function () {
                index += 1;
                if (index >= $scope.images.length)
                    index = 0;
                if ($scope.images.length == 0)
                    return '';
                return $scope.images[index];
            };
            if ($scope.images.length > 0) {
                $scope.img1 = $scope.images[0];
                $scope.img2 = getNextImage();
            }
            //var watch = $scope.$watch(() => host.width(), (newValue: number, oldValue: number) => {
            //    //div1.width(newValue+'px');
            //    div2.width(newValue+'px');
            //});
            var int = $interval(function () {
                countDown += 1;
                var interval = Number($scope.interval);
                var transition = Number($scope.transition);
                if (countDown >= (interval + transition)) {
                    console.log('greater');
                    countDown = 0;
                    mode = !mode;
                    if (mode) {
                        $scope.img2 = getNextImage();
                    }
                    else {
                        $scope.img1 = getNextImage();
                    }
                }
                //if (countDown == 0) {
                //    console.log(div1);
                //    console.log(div2);
                //    if (mode) {
                //        //console.log('true div1 set to 0%');
                //        div1.css('left', '0%');
                //        div2.css('left', '101%');
                //        $scope.img2 = getNextImage();
                //    }
                //    else {
                //        //console.log('false div2 set to 0%');
                //        div2.css('left', '0%');
                //        div1.css('left', '101%');
                //        $scope.img1 = getNextImage();
                //    }
                //}
                if (countDown > interval) {
                    var value = Math.round(-((countDown - interval) / transition) * 100);
                    if (mode) {
                        //console.log('true div1: ' + value);
                        //console.log('true div2: ' + (100+value));
                        //div1.css('left', value.toString() + '%');
                        //div2.css('left', (100 + value).toString() + '%');
                        div1.fadeOut(transition * 25);
                        div2.fadeIn(transition * 25);
                    }
                    else {
                        //console.log('false div1: ' + (100 + value));
                        //console.log('false div2: ' + value);
                        //div2.css('left', value.toString() + '%');
                        //div1.css('left', (100 + value).toString() + '%');
                        div2.fadeOut(transition * 25);
                        div1.fadeIn(transition * 25);
                    }
                }
                //console.log('div1 left:'+ div1.css('left'));
                //console.log('div2 left:'+div2.css('left'));
                //console.log(interval + transition);
                //console.log(countDown);
            }, 50);
            $scope.$on('$destroy', function (event) {
                if (angular.isDefined(int))
                    $interval.cancel(int);
            });
        }
        return ImageSlideController;
    }());
    ngstd.ImageSlideController = ImageSlideController;
    var ImageSlideDirective = (function (_super) {
        __extends(ImageSlideDirective, _super);
        function ImageSlideDirective() {
            _super.call(this);
            this.restrict = ngstd.DirectiveRestrict.E;
            this.templateUrl = 'ImageSlide.html';
            this.scope.images = ngstd.BindingRestrict.OptionalBoth;
            this.scope.interval = ngstd.BindingRestrict.In;
            this.scope.transition = ngstd.BindingRestrict.In;
            this.controller = ImageSlideController;
        }
        return ImageSlideDirective;
    }(ngstd.AngularDirective));
    ngstd.ImageSlideDirective = ImageSlideDirective;
})(ngstd || (ngstd = {}));
/**
 * PHPPostObj is used to post command to the php service; It is used by the rpc.html and php.html;
 */
var PHPPostObj = (function () {
    function PHPPostObj() {
        this.value = [];
    }
    return PHPPostObj;
}());
/**
 * FileBuilder is the interface to make php service to create/write specific file on the server side; It is used by rpc.html and php.html;
 */
var FileBuiler = (function () {
    function FileBuiler() {
    }
    return FileBuiler;
}());
/**
 * CompilerInclude defines patterns required by RPC and PHP compiler;
 */
var CompilerPattern = (function () {
    function CompilerPattern() {
    }
    CompilerPattern.ptnRPCInclude = /\/\/rpc(\s+include\s+(('[\w\d]+'\s*)*)|)\s*/ig;
    CompilerPattern.ptnIncludeFile = /'([\w\-]+)'/ig;
    CompilerPattern.ptnPHPInclude = /\/\/php(\s+include\s+(('[\w\d]+'\s*)*)|)\s*/ig;
    CompilerPattern.ptnService = /(^|\n)\s*(export\s+|)(interface|class)\s+(\w+)\s*\{/g;
    return CompilerPattern;
}());
/**
 * The standard pattern libraries for analyzing typescript entities;
 */
var StdPatterns = (function () {
    function StdPatterns() {
    }
    StdPatterns.ptnModule = /(^|\n)\s*module\s+(\w+)\s*\{/g;
    StdPatterns.ptnClass = /(^|\n)\s*(export\s+|)class\s+(\w+)\s*\{/g;
    StdPatterns.ptnInterface = /(^|\n)\s*(export\s+|)interface\s+(\w+)\s*\{/g;
    StdPatterns.ptnInterfaceMethod = /([\w][\w\d\.]*)\s*\(((\s*([\w][\w\d\.]*)\s*\:\s*([\w][\w\d\.]*)(|\s*\[\s*\])\s*(|\,))*)\)\s*\:\s*(([\w][\w\d\.]*)(\s*\[\s*\]|))/g;
    StdPatterns.ptnParameter = /\s*([\w][\w\d\.]*)\s*\:\s*(([\w][\w\d\.]*)\s*(\[\s*\]|))/g;
    return StdPatterns;
}());
/**
 * class for registering RPC calls for remote service; you must pass the $http service to this class so as to make RPC calls work;
 */
var RPC = (function () {
    function RPC() {
    }
    return RPC;
}());
function ngInject() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i - 0] = arguments[_i];
    }
    var services = [];
    for (var i = 0; i < args.length; i++) {
        switch (args[i]) {
            case ns.http:
                services.push('$http');
                break;
            case ns.scope:
                services.push('$scope');
                break;
        }
    }
    return services;
}
var ns;
(function (ns) {
    ns[ns["http"] = 0] = "http";
    ns[ns["scope"] = 1] = "scope";
    ns[ns["rootScope"] = 2] = "rootScope";
})(ns || (ns = {}));
//# sourceMappingURL=ngstd.js.map