<?php

namespace data {
	class port
	{
		public $mySQLi;
		
		public function __construct($server, $username, $password, $database)
		{
			$this->mySQLi = mysqli_connect($server, $username, $password, $database);
		}
		
		public function createStatement($sql)
		{
			$stmt = $this->mySQLi->stmt_init();
			$stmt->prepare($sql);
			return $stmt;
		}
		
		public function getDataObjects(\mysqli_stmt $stmt)
		{
			$stmt->execute();
			$list = array();
			$resultMetadata = $stmt->result_metadata();
			if ($resultMetadata) {
				$fields = array();
				while ($fieldmeta = mysqli_fetch_field($resultMetadata)) {
					array_push($fields, $fieldmeta->name);
				}
				mysqli_free_result($resultMetadata);
				$result = $stmt->get_result();
				while ($row = mysqli_fetch_array($result)) {
					$obj = array();
					for ($i = 0; $i < sizeof($fields); $i++) {
						$obj[$fields[$i]] = $row[$i];
					}
					array_push($list, $obj);
				}
				mysqli_free_result($result);
			}
			return $list;
		}
		
		public function fetchFirstValue(array $arr)
		{
			foreach (array_keys($arr) as $key) {
				return $arr[$key];
			}
		}
		
		public function fetchFirstKeyValuePair(array $arr)
		{
			foreach (array_keys($arr) as $key) {
				$kvp = new KeyValuePair();
				$kvp->key = $key;
				$kvp->value = $arr[$key];
				return $kvp;
			}
		}
		
		public function __destruct()
		{
			$this->mySQLi->close();
		}
		
	}

	class KeyValuePair
	{
		public $key;
		
		public $value;
		
	}
}
?>